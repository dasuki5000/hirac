import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';
import { hashPassword } from '@/lib/auth';

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { name, email, password, role, organization_id, department_id } = await request.json();
    
    // Validate required fields
    if (!name || !email || !password || !role || !organization_id) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate role
    if (!['admin', 'safety_officer', 'employee'].includes(role)) {
      return Response.json({
        status: 'error',
        message: 'Invalid role'
      }, { status: 400 });
    }
    
    // Check if email already exists
    const existingUser = await env.DB.prepare(
      "SELECT id FROM Users WHERE email = ?"
    ).bind(email).first();
    
    if (existingUser) {
      return Response.json({
        status: 'error',
        message: 'Email already in use'
      }, { status: 409 });
    }
    
    // Hash password
    const password_hash = await hashPassword(password);
    
    // Insert new user
    const result = await env.DB.prepare(
      `INSERT INTO Users (name, email, password_hash, role, organization_id, department_id, created_at, updated_at) 
       VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`
    ).bind(name, email, password_hash, role, organization_id, department_id || null).run();
    
    if (!result.success) {
      throw new Error('Failed to create user');
    }
    
    // Get the inserted user ID
    const userId = result.meta?.last_row_id;
    
    return Response.json({
      status: 'success',
      message: 'User created successfully',
      data: {
        id: userId,
        name,
        email,
        role,
        organization_id,
        department_id: department_id || null
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Register Error:', error);
    return Response.json({
      status: 'error',
      message: 'Registration failed',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
