import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';
import { hashPassword, verifyPassword } from '@/lib/auth';

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { email, password } = await request.json();
    
    if (!email || !password) {
      return Response.json({
        status: 'error',
        message: 'Email and password are required'
      }, { status: 400 });
    }
    
    // Find user by email
    const user = await env.DB.prepare(
      "SELECT id, name, email, password_hash, role, organization_id, department_id FROM Users WHERE email = ?"
    ).bind(email).first();
    
    if (!user) {
      return Response.json({
        status: 'error',
        message: 'Invalid email or password'
      }, { status: 401 });
    }
    
    // Verify password
    const isValid = await verifyPassword(password, user.password_hash);
    
    if (!isValid) {
      return Response.json({
        status: 'error',
        message: 'Invalid email or password'
      }, { status: 401 });
    }
    
    // Get organization and department info
    const organization = await env.DB.prepare(
      "SELECT id, name FROM Organizations WHERE id = ?"
    ).bind(user.organization_id).first();
    
    let department = null;
    if (user.department_id) {
      department = await env.DB.prepare(
        "SELECT id, name FROM Departments WHERE id = ?"
      ).bind(user.department_id).first();
    }
    
    // Return user data without password
    return Response.json({
      status: 'success',
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          organization: organization || null,
          department: department || null
        }
      }
    });
    
  } catch (error) {
    console.error('Login Error:', error);
    return Response.json({
      status: 'error',
      message: 'Authentication failed',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
