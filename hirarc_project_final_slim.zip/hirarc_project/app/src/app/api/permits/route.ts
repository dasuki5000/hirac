import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(request: NextRequest) {
  const { env } = getCloudflareContext();
  const { searchParams } = new URL(request.url);
  
  try {
    // Get pagination parameters
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '10');
    const offset = (page - 1) * pageSize;
    
    // Get filters if provided
    const departmentId = searchParams.get('department_id');
    const status = searchParams.get('status');
    
    // Build query based on parameters
    let query = `
      SELECT 
        p.id, 
        p.permit_number, 
        p.work_description, 
        p.location,
        p.status,
        p.start_date,
        p.end_date,
        p.created_at,
        d.name as department_name,
        u.name as created_by_name,
        (SELECT COUNT(*) FROM Permit_Hazards WHERE permit_id = p.id) as hazard_count
      FROM Permits p
      JOIN Departments d ON p.department_id = d.id
      JOIN Users u ON p.created_by = u.id
    `;
    
    const queryParams = [];
    const whereConditions = [];
    
    if (departmentId) {
      whereConditions.push("p.department_id = ?");
      queryParams.push(departmentId);
    }
    
    if (status && ['draft', 'pending_approval', 'approved', 'in_progress', 'completed', 'cancelled'].includes(status)) {
      whereConditions.push("p.status = ?");
      queryParams.push(status);
    }
    
    if (whereConditions.length > 0) {
      query += " WHERE " + whereConditions.join(" AND ");
    }
    
    query += " ORDER BY p.start_date DESC LIMIT ? OFFSET ?";
    queryParams.push(pageSize, offset);
    
    // Execute query
    const stmt = env.DB.prepare(query);
    const bindResult = queryParams.length > 0 ? stmt.bind(...queryParams) : stmt;
    const permits = await bindResult.all();
    
    // Get total count for pagination
    let countQuery = "SELECT COUNT(*) as count FROM Permits";
    const countWhereConditions = [];
    const countParams = [];
    
    if (departmentId) {
      countWhereConditions.push("department_id = ?");
      countParams.push(departmentId);
    }
    
    if (status && ['draft', 'pending_approval', 'approved', 'in_progress', 'completed', 'cancelled'].includes(status)) {
      countWhereConditions.push("status = ?");
      countParams.push(status);
    }
    
    if (countWhereConditions.length > 0) {
      countQuery += " WHERE " + countWhereConditions.join(" AND ");
    }
    
    const countStmt = env.DB.prepare(countQuery);
    const countBindResult = countParams.length > 0 ? countStmt.bind(...countParams) : countStmt;
    const totalCount = await countBindResult.first();
    
    return Response.json({
      status: 'success',
      data: {
        permits: permits.results,
        pagination: {
          total: totalCount?.count || 0,
          page,
          pageSize,
          totalPages: Math.ceil((totalCount?.count || 0) / pageSize)
        }
      }
    });
    
  } catch (error) {
    console.error('Get Permits Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve permits',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { 
      work_description, 
      location, 
      department_id, 
      start_date, 
      end_date, 
      created_by 
    } = await request.json();
    
    // Validate required fields
    if (!work_description || !location || !department_id || !start_date || !end_date || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Generate permit number (format: PTW-YYYYMMDD-XXX)
    const today = new Date();
    const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
    
    // Get the latest permit number for today to increment
    const latestPermit = await env.DB.prepare(`
      SELECT permit_number 
      FROM Permits 
      WHERE permit_number LIKE ?
      ORDER BY permit_number DESC
      LIMIT 1
    `).bind(`PTW-${dateStr}-%`).first();
    
    let permitNumber;
    if (latestPermit) {
      const lastNumber = parseInt(latestPermit.permit_number.split('-')[2]);
      permitNumber = `PTW-${dateStr}-${(lastNumber + 1).toString().padStart(3, '0')}`;
    } else {
      permitNumber = `PTW-${dateStr}-001`;
    }
    
    // Insert new permit
    const result = await env.DB.prepare(`
      INSERT INTO Permits (
        permit_number, 
        work_description, 
        location, 
        department_id, 
        status, 
        start_date, 
        end_date, 
        created_by, 
        created_at, 
        updated_at
      )
      VALUES (?, ?, ?, ?, 'draft', ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(
      permitNumber,
      work_description,
      location,
      department_id,
      start_date,
      end_date,
      created_by
    ).run();
    
    if (!result.success) {
      throw new Error('Failed to create permit');
    }
    
    // Get the inserted permit ID
    const permitId = result.meta?.last_row_id;
    
    return Response.json({
      status: 'success',
      message: 'Permit created successfully',
      data: {
        id: permitId,
        permit_number: permitNumber,
        work_description,
        location,
        department_id,
        status: 'draft',
        start_date,
        end_date,
        created_by
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Create Permit Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to create permit',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
