import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string, approverId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: permitId, approverId } = params;
  
  try {
    const { status, comments, user_id } = await request.json();
    
    // Validate required fields
    if (!status || !user_id) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate status
    if (!['approved', 'rejected'].includes(status)) {
      return Response.json({
        status: 'error',
        message: 'Invalid status'
      }, { status: 400 });
    }
    
    // Check if permit exists
    const existingPermit = await env.DB.prepare(
      "SELECT id, status FROM Permits WHERE id = ?"
    ).bind(permitId).first();
    
    if (!existingPermit) {
      return Response.json({
        status: 'error',
        message: 'Permit not found'
      }, { status: 404 });
    }
    
    // Check if permit is in a valid status for approval
    if (!['draft', 'pending_approval'].includes(existingPermit.status)) {
      return Response.json({
        status: 'error',
        message: 'Permit is not in a valid status for approval'
      }, { status: 400 });
    }
    
    // Check if approver exists
    const existingApprover = await env.DB.prepare(
      "SELECT id, user_id, status FROM Permit_Approvers WHERE id = ? AND permit_id = ?"
    ).bind(approverId, permitId).first();
    
    if (!existingApprover) {
      return Response.json({
        status: 'error',
        message: 'Approver not found'
      }, { status: 404 });
    }
    
    // Check if user is the approver
    if (existingApprover.user_id != user_id) {
      return Response.json({
        status: 'error',
        message: 'Only the assigned approver can approve or reject'
      }, { status: 403 });
    }
    
    // Check if already approved or rejected
    if (existingApprover.status !== 'pending') {
      return Response.json({
        status: 'error',
        message: 'Approval has already been processed'
      }, { status: 400 });
    }
    
    // Start a transaction
    await env.DB.exec('BEGIN TRANSACTION');
    
    try {
      // Update approver status
      const result = await env.DB.prepare(`
        UPDATE Permit_Approvers
        SET status = ?, comments = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ? AND permit_id = ?
      `).bind(status, comments || null, approverId, permitId).run();
      
      if (!result.success) {
        throw new Error('Failed to update approver status');
      }
      
      // If rejected, update permit status to draft
      if (status === 'rejected') {
        await env.DB.prepare(`
          UPDATE Permits
          SET status = 'draft', updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `).bind(permitId).run();
      } else if (status === 'approved') {
        // If approved, check if all approvers have approved
        const pendingApprovers = await env.DB.prepare(`
          SELECT COUNT(*) as count
          FROM Permit_Approvers
          WHERE permit_id = ? AND status = 'pending'
        `).bind(permitId).first();
        
        // If no pending approvers remain, update permit status to approved
        if (pendingApprovers && pendingApprovers.count === 0) {
          await env.DB.prepare(`
            UPDATE Permits
            SET status = 'approved', approved_by = ?, approval_date = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `).bind(user_id, permitId).run();
        } else if (existingPermit.status === 'draft') {
          // If still in draft and at least one approval received, update to pending_approval
          await env.DB.prepare(`
            UPDATE Permits
            SET status = 'pending_approval', updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `).bind(permitId).run();
        }
      }
      
      // Commit the transaction
      await env.DB.exec('COMMIT');
      
      return Response.json({
        status: 'success',
        message: `Permit ${status === 'approved' ? 'approved' : 'rejected'} successfully`,
        data: {
          id: approverId,
          permit_id: permitId,
          status,
          comments: comments || null
        }
      });
      
    } catch (error) {
      // Rollback the transaction on error
      await env.DB.exec('ROLLBACK');
      throw error;
    }
    
  } catch (error) {
    console.error('Process Approval Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to process approval',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
