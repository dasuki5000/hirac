import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const permitId = params.id;
  
  try {
    const { user_id, role, created_by } = await request.json();
    
    // Validate required fields
    if (!user_id || !role || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate role
    if (!['safety_officer', 'supervisor', 'manager', 'engineer'].includes(role)) {
      return Response.json({
        status: 'error',
        message: 'Invalid role'
      }, { status: 400 });
    }
    
    // Check if permit exists
    const existingPermit = await env.DB.prepare(
      "SELECT id, status FROM Permits WHERE id = ?"
    ).bind(permitId).first();
    
    if (!existingPermit) {
      return Response.json({
        status: 'error',
        message: 'Permit not found'
      }, { status: 404 });
    }
    
    // Only draft permits can have approvers added
    if (existingPermit.status !== 'draft') {
      return Response.json({
        status: 'error',
        message: 'Approvers can only be added to draft permits'
      }, { status: 400 });
    }
    
    // Check if user exists
    const existingUser = await env.DB.prepare(
      "SELECT id FROM Users WHERE id = ?"
    ).bind(user_id).first();
    
    if (!existingUser) {
      return Response.json({
        status: 'error',
        message: 'User not found'
      }, { status: 404 });
    }
    
    // Check if user is already an approver for this permit
    const existingApprover = await env.DB.prepare(
      "SELECT id FROM Permit_Approvers WHERE permit_id = ? AND user_id = ?"
    ).bind(permitId, user_id).first();
    
    if (existingApprover) {
      return Response.json({
        status: 'error',
        message: 'User is already an approver for this permit'
      }, { status: 409 });
    }
    
    // Insert new approver
    const result = await env.DB.prepare(`
      INSERT INTO Permit_Approvers (permit_id, user_id, role, status, created_by, created_at, updated_at)
      VALUES (?, ?, ?, 'pending', ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(permitId, user_id, role, created_by).run();
    
    if (!result.success) {
      throw new Error('Failed to add approver to permit');
    }
    
    // Get the inserted approver ID
    const approverId = result.meta?.last_row_id;
    
    // Get user details for response
    const userDetails = await env.DB.prepare(
      "SELECT name FROM Users WHERE id = ?"
    ).bind(user_id).first();
    
    return Response.json({
      status: 'success',
      message: 'Approver added to permit successfully',
      data: {
        id: approverId,
        permit_id: permitId,
        user_id,
        user_name: userDetails?.name,
        role,
        status: 'pending',
        created_by
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Add Approver to Permit Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to add approver to permit',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
