import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const permitId = params.id;
  
  try {
    // Get permit details
    const permit = await env.DB.prepare(`
      SELECT 
        p.id, 
        p.permit_number, 
        p.work_description, 
        p.location,
        p.department_id,
        p.status,
        p.start_date,
        p.end_date,
        p.approved_by,
        p.approval_date,
        p.created_by,
        p.created_at,
        p.updated_at,
        d.name as department_name,
        u.name as created_by_name,
        CASE WHEN p.approved_by IS NULL THEN NULL ELSE au.name END as approved_by_name
      FROM Permits p
      JOIN Departments d ON p.department_id = d.id
      JOIN Users u ON p.created_by = u.id
      LEFT JOIN Users au ON p.approved_by = au.id
      WHERE p.id = ?
    `).bind(permitId).first();
    
    if (!permit) {
      return Response.json({
        status: 'error',
        message: 'Permit not found'
      }, { status: 404 });
    }
    
    // Get hazards for this permit
    const hazards = await env.DB.prepare(`
      SELECT 
        ph.id,
        ph.hazard_id,
        ph.control_id,
        h.description as hazard_description,
        h.hazard_type,
        cm.description as control_description,
        cm.control_type,
        a.id as activity_id,
        a.name as activity_name
      FROM Permit_Hazards ph
      JOIN Hazards h ON ph.hazard_id = h.id
      JOIN Activities a ON h.activity_id = a.id
      LEFT JOIN Control_Measures cm ON ph.control_id = cm.id
      WHERE ph.permit_id = ?
      ORDER BY h.hazard_type, h.description
    `).bind(permitId).all();
    
    // Get approvers for this permit
    const approvers = await env.DB.prepare(`
      SELECT 
        pa.id,
        pa.user_id,
        pa.role,
        pa.status,
        pa.comments,
        pa.created_at,
        u.name as user_name
      FROM Permit_Approvers pa
      JOIN Users u ON pa.user_id = u.id
      WHERE pa.permit_id = ?
      ORDER BY pa.created_at
    `).bind(permitId).all();
    
    return Response.json({
      status: 'success',
      data: {
        permit,
        hazards: hazards.results,
        approvers: approvers.results
      }
    });
    
  } catch (error) {
    console.error('Get Permit Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve permit details',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const permitId = params.id;
  
  try {
    const { 
      work_description, 
      location, 
      department_id, 
      status, 
      start_date, 
      end_date 
    } = await request.json();
    
    // Validate required fields
    if (!work_description || !location || !department_id || !status || !start_date || !end_date) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate status
    if (!['draft', 'pending_approval', 'approved', 'in_progress', 'completed', 'cancelled'].includes(status)) {
      return Response.json({
        status: 'error',
        message: 'Invalid status'
      }, { status: 400 });
    }
    
    // Check if permit exists
    const existingPermit = await env.DB.prepare(
      "SELECT id, status FROM Permits WHERE id = ?"
    ).bind(permitId).first();
    
    if (!existingPermit) {
      return Response.json({
        status: 'error',
        message: 'Permit not found'
      }, { status: 404 });
    }
    
    // Check if status transition is valid
    if (existingPermit.status !== status) {
      // Cannot change from approved/in_progress/completed back to draft
      if (['approved', 'in_progress', 'completed'].includes(existingPermit.status) && status === 'draft') {
        return Response.json({
          status: 'error',
          message: 'Cannot change permit status from ' + existingPermit.status + ' to draft'
        }, { status: 400 });
      }
      
      // Cannot change to approved without going through approval process
      if (status === 'approved' && existingPermit.status !== 'pending_approval') {
        return Response.json({
          status: 'error',
          message: 'Cannot change permit status to approved without going through approval process'
        }, { status: 400 });
      }
    }
    
    // Update permit
    const result = await env.DB.prepare(`
      UPDATE Permits
      SET 
        work_description = ?, 
        location = ?, 
        department_id = ?, 
        status = ?, 
        start_date = ?, 
        end_date = ?, 
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      work_description,
      location,
      department_id,
      status,
      start_date,
      end_date,
      permitId
    ).run();
    
    if (!result.success) {
      throw new Error('Failed to update permit');
    }
    
    return Response.json({
      status: 'success',
      message: 'Permit updated successfully',
      data: {
        id: permitId,
        work_description,
        location,
        department_id,
        status,
        start_date,
        end_date
      }
    });
    
  } catch (error) {
    console.error('Update Permit Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to update permit',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const permitId = params.id;
  
  try {
    // Check if permit exists
    const existingPermit = await env.DB.prepare(
      "SELECT id, status FROM Permits WHERE id = ?"
    ).bind(permitId).first();
    
    if (!existingPermit) {
      return Response.json({
        status: 'error',
        message: 'Permit not found'
      }, { status: 404 });
    }
    
    // Only draft permits can be deleted
    if (existingPermit.status !== 'draft') {
      return Response.json({
        status: 'error',
        message: 'Only draft permits can be deleted'
      }, { status: 400 });
    }
    
    // Start a transaction
    await env.DB.exec('BEGIN TRANSACTION');
    
    try {
      // Delete permit approvers
      await env.DB.prepare(
        "DELETE FROM Permit_Approvers WHERE permit_id = ?"
      ).bind(permitId).run();
      
      // Delete permit hazards
      await env.DB.prepare(
        "DELETE FROM Permit_Hazards WHERE permit_id = ?"
      ).bind(permitId).run();
      
      // Delete permit
      const result = await env.DB.prepare(
        "DELETE FROM Permits WHERE id = ?"
      ).bind(permitId).run();
      
      if (!result.success) {
        throw new Error('Failed to delete permit');
      }
      
      // Commit the transaction
      await env.DB.exec('COMMIT');
      
      return Response.json({
        status: 'success',
        message: 'Permit deleted successfully'
      });
      
    } catch (error) {
      // Rollback the transaction on error
      await env.DB.exec('ROLLBACK');
      throw error;
    }
    
  } catch (error) {
    console.error('Delete Permit Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to delete permit',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
