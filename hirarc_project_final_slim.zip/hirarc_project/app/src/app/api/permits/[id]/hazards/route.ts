import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const permitId = params.id;
  
  try {
    const { hazard_id, control_id } = await request.json();
    
    // Validate required fields
    if (!hazard_id) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Check if permit exists
    const existingPermit = await env.DB.prepare(
      "SELECT id, status FROM Permits WHERE id = ?"
    ).bind(permitId).first();
    
    if (!existingPermit) {
      return Response.json({
        status: 'error',
        message: 'Permit not found'
      }, { status: 404 });
    }
    
    // Only draft or pending_approval permits can have hazards added
    if (!['draft', 'pending_approval'].includes(existingPermit.status)) {
      return Response.json({
        status: 'error',
        message: 'Hazards can only be added to draft or pending approval permits'
      }, { status: 400 });
    }
    
    // Check if hazard exists
    const existingHazard = await env.DB.prepare(
      "SELECT id FROM Hazards WHERE id = ?"
    ).bind(hazard_id).first();
    
    if (!existingHazard) {
      return Response.json({
        status: 'error',
        message: 'Hazard not found'
      }, { status: 404 });
    }
    
    // Check if control exists if provided
    if (control_id) {
      const existingControl = await env.DB.prepare(
        "SELECT id FROM Control_Measures WHERE id = ? AND hazard_id = ?"
      ).bind(control_id, hazard_id).first();
      
      if (!existingControl) {
        return Response.json({
          status: 'error',
          message: 'Control measure not found or not associated with the specified hazard'
        }, { status: 404 });
      }
    }
    
    // Check if hazard is already linked to this permit
    const existingLink = await env.DB.prepare(
      "SELECT id FROM Permit_Hazards WHERE permit_id = ? AND hazard_id = ?"
    ).bind(permitId, hazard_id).first();
    
    if (existingLink) {
      // Update existing link if control_id is different
      if (control_id) {
        const updateResult = await env.DB.prepare(`
          UPDATE Permit_Hazards
          SET control_id = ?, updated_at = CURRENT_TIMESTAMP
          WHERE permit_id = ? AND hazard_id = ?
        `).bind(control_id, permitId, hazard_id).run();
        
        if (!updateResult.success) {
          throw new Error('Failed to update permit hazard link');
        }
        
        return Response.json({
          status: 'success',
          message: 'Permit hazard control updated successfully',
          data: {
            id: existingLink.id,
            permit_id: permitId,
            hazard_id,
            control_id
          }
        });
      } else {
        return Response.json({
          status: 'error',
          message: 'Hazard is already linked to this permit'
        }, { status: 409 });
      }
    }
    
    // Insert new permit hazard link
    const result = await env.DB.prepare(`
      INSERT INTO Permit_Hazards (permit_id, hazard_id, control_id, created_at, updated_at)
      VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(permitId, hazard_id, control_id || null).run();
    
    if (!result.success) {
      throw new Error('Failed to link hazard to permit');
    }
    
    // Get the inserted link ID
    const linkId = result.meta?.last_row_id;
    
    // Get hazard and control details for response
    const hazardDetails = await env.DB.prepare(`
      SELECT 
        h.description as hazard_description,
        h.hazard_type,
        a.name as activity_name
      FROM Hazards h
      JOIN Activities a ON h.activity_id = a.id
      WHERE h.id = ?
    `).bind(hazard_id).first();
    
    let controlDetails = null;
    if (control_id) {
      controlDetails = await env.DB.prepare(`
        SELECT 
          description as control_description,
          control_type
        FROM Control_Measures
        WHERE id = ?
      `).bind(control_id).first();
    }
    
    return Response.json({
      status: 'success',
      message: 'Hazard linked to permit successfully',
      data: {
        id: linkId,
        permit_id: permitId,
        hazard_id,
        control_id: control_id || null,
        hazard: hazardDetails,
        control: controlDetails
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Link Hazard to Permit Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to link hazard to permit',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
