import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(request: NextRequest) {
  const { env } = getCloudflareContext();
  const { searchParams } = new URL(request.url);
  
  try {
    // Get pagination parameters
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '10');
    const offset = (page - 1) * pageSize;
    
    // Get department filter if provided
    const departmentId = searchParams.get('department_id');
    const status = searchParams.get('status');
    
    // Build query based on parameters
    let query = `
      SELECT 
        ap.id, 
        ap.title, 
        ap.description, 
        ap.status,
        ap.scheduled_date,
        ap.created_at,
        d.name as department_name,
        u.name as created_by_name,
        (SELECT COUNT(*) FROM Audit_Findings WHERE audit_plan_id = ap.id) as finding_count
      FROM Audit_Plans ap
      JOIN Departments d ON ap.department_id = d.id
      JOIN Users u ON ap.created_by = u.id
    `;
    
    const queryParams = [];
    const whereConditions = [];
    
    if (departmentId) {
      whereConditions.push("ap.department_id = ?");
      queryParams.push(departmentId);
    }
    
    if (status && ['planned', 'in_progress', 'completed', 'cancelled'].includes(status)) {
      whereConditions.push("ap.status = ?");
      queryParams.push(status);
    }
    
    if (whereConditions.length > 0) {
      query += " WHERE " + whereConditions.join(" AND ");
    }
    
    query += " ORDER BY ap.scheduled_date DESC LIMIT ? OFFSET ?";
    queryParams.push(pageSize, offset);
    
    // Execute query
    const stmt = env.DB.prepare(query);
    const bindResult = queryParams.length > 0 ? stmt.bind(...queryParams) : stmt;
    const auditPlans = await bindResult.all();
    
    // Get total count for pagination
    let countQuery = "SELECT COUNT(*) as count FROM Audit_Plans";
    const countWhereConditions = [];
    const countParams = [];
    
    if (departmentId) {
      countWhereConditions.push("department_id = ?");
      countParams.push(departmentId);
    }
    
    if (status && ['planned', 'in_progress', 'completed', 'cancelled'].includes(status)) {
      countWhereConditions.push("status = ?");
      countParams.push(status);
    }
    
    if (countWhereConditions.length > 0) {
      countQuery += " WHERE " + countWhereConditions.join(" AND ");
    }
    
    const countStmt = env.DB.prepare(countQuery);
    const countBindResult = countParams.length > 0 ? countStmt.bind(...countParams) : countStmt;
    const totalCount = await countBindResult.first();
    
    return Response.json({
      status: 'success',
      data: {
        audit_plans: auditPlans.results,
        pagination: {
          total: totalCount?.count || 0,
          page,
          pageSize,
          totalPages: Math.ceil((totalCount?.count || 0) / pageSize)
        }
      }
    });
    
  } catch (error) {
    console.error('Get Audit Plans Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve audit plans',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { title, description, department_id, scheduled_date, created_by } = await request.json();
    
    // Validate required fields
    if (!title || !department_id || !scheduled_date || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Insert new audit plan
    const result = await env.DB.prepare(`
      INSERT INTO Audit_Plans (title, description, department_id, status, created_by, scheduled_date, created_at, updated_at)
      VALUES (?, ?, ?, 'planned', ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(title, description || null, department_id, created_by, scheduled_date).run();
    
    if (!result.success) {
      throw new Error('Failed to create audit plan');
    }
    
    // Get the inserted audit plan ID
    const auditPlanId = result.meta?.last_row_id;
    
    return Response.json({
      status: 'success',
      message: 'Audit plan created successfully',
      data: {
        id: auditPlanId,
        title,
        description,
        department_id,
        status: 'planned',
        created_by,
        scheduled_date
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Create Audit Plan Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to create audit plan',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
