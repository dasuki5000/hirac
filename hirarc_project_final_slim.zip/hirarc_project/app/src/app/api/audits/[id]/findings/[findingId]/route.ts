import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string, findingId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: auditPlanId, findingId } = params;
  
  try {
    // Get finding details
    const finding = await env.DB.prepare(`
      SELECT 
        af.id, 
        af.audit_plan_id,
        af.description, 
        af.severity,
        af.status,
        af.photo_url,
        af.created_by,
        af.created_at,
        af.updated_at,
        u.name as created_by_name,
        ap.title as audit_plan_title
      FROM Audit_Findings af
      JOIN Users u ON af.created_by = u.id
      JOIN Audit_Plans ap ON af.audit_plan_id = ap.id
      WHERE af.id = ? AND af.audit_plan_id = ?
    `).bind(findingId, auditPlanId).first();
    
    if (!finding) {
      return Response.json({
        status: 'error',
        message: 'Audit finding not found'
      }, { status: 404 });
    }
    
    // Get corrective actions for this finding
    const actions = await env.DB.prepare(`
      SELECT 
        ca.id,
        ca.description,
        ca.assigned_to,
        ca.due_date,
        ca.status,
        ca.created_at,
        u.name as assigned_to_name,
        cu.name as created_by_name
      FROM Corrective_Actions ca
      JOIN Users u ON ca.assigned_to = u.id
      JOIN Users cu ON ca.created_by = cu.id
      WHERE ca.finding_id = ?
      ORDER BY ca.due_date ASC
    `).bind(findingId).all();
    
    return Response.json({
      status: 'success',
      data: {
        finding,
        actions: actions.results
      }
    });
    
  } catch (error) {
    console.error('Get Audit Finding Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve audit finding details',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string, findingId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: auditPlanId, findingId } = params;
  
  try {
    const { description, severity, status, photo_url } = await request.json();
    
    // Validate required fields
    if (!description || !severity || !status) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate severity
    if (!['critical', 'major', 'minor', 'observation'].includes(severity)) {
      return Response.json({
        status: 'error',
        message: 'Invalid severity'
      }, { status: 400 });
    }
    
    // Validate status
    if (!['open', 'in_progress', 'closed'].includes(status)) {
      return Response.json({
        status: 'error',
        message: 'Invalid status'
      }, { status: 400 });
    }
    
    // Check if finding exists
    const existingFinding = await env.DB.prepare(
      "SELECT id FROM Audit_Findings WHERE id = ? AND audit_plan_id = ?"
    ).bind(findingId, auditPlanId).first();
    
    if (!existingFinding) {
      return Response.json({
        status: 'error',
        message: 'Audit finding not found'
      }, { status: 404 });
    }
    
    // Update finding
    const result = await env.DB.prepare(`
      UPDATE Audit_Findings
      SET description = ?, severity = ?, status = ?, photo_url = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND audit_plan_id = ?
    `).bind(description, severity, status, photo_url || null, findingId, auditPlanId).run();
    
    if (!result.success) {
      throw new Error('Failed to update audit finding');
    }
    
    // If status is changed to 'closed', check if all findings are closed
    if (status === 'closed') {
      const openFindings = await env.DB.prepare(`
        SELECT COUNT(*) as count 
        FROM Audit_Findings 
        WHERE audit_plan_id = ? AND status != 'closed'
      `).bind(auditPlanId).first();
      
      // If no open findings remain, update audit plan status to 'completed'
      if (openFindings && openFindings.count === 0) {
        await env.DB.prepare(`
          UPDATE Audit_Plans
          SET status = 'completed', updated_at = CURRENT_TIMESTAMP
          WHERE id = ? AND status = 'in_progress'
        `).bind(auditPlanId).run();
      }
    }
    
    return Response.json({
      status: 'success',
      message: 'Audit finding updated successfully',
      data: {
        id: findingId,
        audit_plan_id: auditPlanId,
        description,
        severity,
        status,
        photo_url: photo_url || null
      }
    });
    
  } catch (error) {
    console.error('Update Audit Finding Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to update audit finding',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string, findingId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: auditPlanId, findingId } = params;
  
  try {
    // Check if finding exists
    const existingFinding = await env.DB.prepare(
      "SELECT id FROM Audit_Findings WHERE id = ? AND audit_plan_id = ?"
    ).bind(findingId, auditPlanId).first();
    
    if (!existingFinding) {
      return Response.json({
        status: 'error',
        message: 'Audit finding not found'
      }, { status: 404 });
    }
    
    // Check if finding has corrective actions
    const actionCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Corrective_Actions WHERE finding_id = ?"
    ).bind(findingId).first();
    
    if (actionCount && actionCount.count > 0) {
      return Response.json({
        status: 'error',
        message: 'Cannot delete finding with associated corrective actions'
      }, { status: 409 });
    }
    
    // Delete finding
    const result = await env.DB.prepare(
      "DELETE FROM Audit_Findings WHERE id = ? AND audit_plan_id = ?"
    ).bind(findingId, auditPlanId).run();
    
    if (!result.success) {
      throw new Error('Failed to delete audit finding');
    }
    
    return Response.json({
      status: 'success',
      message: 'Audit finding deleted successfully'
    });
    
  } catch (error) {
    console.error('Delete Audit Finding Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to delete audit finding',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
