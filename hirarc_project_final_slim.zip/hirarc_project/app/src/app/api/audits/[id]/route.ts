import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const auditPlanId = params.id;
  
  try {
    // Get audit plan details
    const auditPlan = await env.DB.prepare(`
      SELECT 
        ap.id, 
        ap.title, 
        ap.description, 
        ap.status,
        ap.department_id,
        ap.created_by,
        ap.scheduled_date,
        ap.created_at,
        ap.updated_at,
        d.name as department_name,
        u.name as created_by_name
      FROM Audit_Plans ap
      JOIN Departments d ON ap.department_id = d.id
      JOIN Users u ON ap.created_by = u.id
      WHERE ap.id = ?
    `).bind(auditPlanId).first();
    
    if (!auditPlan) {
      return Response.json({
        status: 'error',
        message: 'Audit plan not found'
      }, { status: 404 });
    }
    
    // Get findings for this audit plan
    const findings = await env.DB.prepare(`
      SELECT 
        af.id,
        af.description,
        af.severity,
        af.status,
        af.photo_url,
        af.created_at,
        u.name as created_by_name,
        (SELECT COUNT(*) FROM Corrective_Actions WHERE finding_id = af.id) as action_count
      FROM Audit_Findings af
      JOIN Users u ON af.created_by = u.id
      WHERE af.audit_plan_id = ?
      ORDER BY 
        CASE af.severity
          WHEN 'critical' THEN 1
          WHEN 'major' THEN 2
          WHEN 'minor' THEN 3
          WHEN 'observation' THEN 4
        END,
        af.created_at DESC
    `).bind(auditPlanId).all();
    
    return Response.json({
      status: 'success',
      data: {
        audit_plan: auditPlan,
        findings: findings.results
      }
    });
    
  } catch (error) {
    console.error('Get Audit Plan Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve audit plan details',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const auditPlanId = params.id;
  
  try {
    const { title, description, status, department_id, scheduled_date } = await request.json();
    
    // Validate required fields
    if (!title || !status || !department_id || !scheduled_date) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate status
    if (!['planned', 'in_progress', 'completed', 'cancelled'].includes(status)) {
      return Response.json({
        status: 'error',
        message: 'Invalid status'
      }, { status: 400 });
    }
    
    // Check if audit plan exists
    const existingPlan = await env.DB.prepare(
      "SELECT id FROM Audit_Plans WHERE id = ?"
    ).bind(auditPlanId).first();
    
    if (!existingPlan) {
      return Response.json({
        status: 'error',
        message: 'Audit plan not found'
      }, { status: 404 });
    }
    
    // Update audit plan
    const result = await env.DB.prepare(`
      UPDATE Audit_Plans
      SET title = ?, description = ?, status = ?, department_id = ?, scheduled_date = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(title, description || null, status, department_id, scheduled_date, auditPlanId).run();
    
    if (!result.success) {
      throw new Error('Failed to update audit plan');
    }
    
    return Response.json({
      status: 'success',
      message: 'Audit plan updated successfully',
      data: {
        id: auditPlanId,
        title,
        description,
        status,
        department_id,
        scheduled_date
      }
    });
    
  } catch (error) {
    console.error('Update Audit Plan Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to update audit plan',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const auditPlanId = params.id;
  
  try {
    // Check if audit plan exists
    const existingPlan = await env.DB.prepare(
      "SELECT id FROM Audit_Plans WHERE id = ?"
    ).bind(auditPlanId).first();
    
    if (!existingPlan) {
      return Response.json({
        status: 'error',
        message: 'Audit plan not found'
      }, { status: 404 });
    }
    
    // Check if audit plan has findings
    const findingCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Audit_Findings WHERE audit_plan_id = ?"
    ).bind(auditPlanId).first();
    
    if (findingCount && findingCount.count > 0) {
      // Instead of deleting, cancel the audit plan
      const result = await env.DB.prepare(`
        UPDATE Audit_Plans
        SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(auditPlanId).run();
      
      if (!result.success) {
        throw new Error('Failed to cancel audit plan');
      }
      
      return Response.json({
        status: 'success',
        message: 'Audit plan has associated findings and has been cancelled instead of deleted'
      });
    } else {
      // Delete audit plan if no findings
      const result = await env.DB.prepare(
        "DELETE FROM Audit_Plans WHERE id = ?"
      ).bind(auditPlanId).run();
      
      if (!result.success) {
        throw new Error('Failed to delete audit plan');
      }
      
      return Response.json({
        status: 'success',
        message: 'Audit plan deleted successfully'
      });
    }
    
  } catch (error) {
    console.error('Delete Audit Plan Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to delete audit plan',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
