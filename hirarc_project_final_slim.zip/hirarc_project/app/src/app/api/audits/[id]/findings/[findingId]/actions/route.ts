import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string, findingId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: auditPlanId, findingId } = params;
  
  try {
    const { description, assigned_to, due_date, status, created_by } = await request.json();
    
    // Validate required fields
    if (!description || !assigned_to || !due_date || !status || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate status
    if (!['assigned', 'in_progress', 'completed', 'verified'].includes(status)) {
      return Response.json({
        status: 'error',
        message: 'Invalid status'
      }, { status: 400 });
    }
    
    // Check if finding exists
    const existingFinding = await env.DB.prepare(
      "SELECT id FROM Audit_Findings WHERE id = ? AND audit_plan_id = ?"
    ).bind(findingId, auditPlanId).first();
    
    if (!existingFinding) {
      return Response.json({
        status: 'error',
        message: 'Audit finding not found'
      }, { status: 404 });
    }
    
    // Check if assigned user exists
    const existingUser = await env.DB.prepare(
      "SELECT id FROM Users WHERE id = ?"
    ).bind(assigned_to).first();
    
    if (!existingUser) {
      return Response.json({
        status: 'error',
        message: 'Assigned user not found'
      }, { status: 404 });
    }
    
    // Insert new corrective action
    const result = await env.DB.prepare(`
      INSERT INTO Corrective_Actions (finding_id, description, assigned_to, due_date, status, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(findingId, description, assigned_to, due_date, status, created_by).run();
    
    if (!result.success) {
      throw new Error('Failed to create corrective action');
    }
    
    // Get the inserted corrective action ID
    const actionId = result.meta?.last_row_id;
    
    // If finding is still 'open', update it to 'in_progress'
    await env.DB.prepare(`
      UPDATE Audit_Findings
      SET status = 'in_progress', updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND status = 'open'
    `).bind(findingId).run();
    
    return Response.json({
      status: 'success',
      message: 'Corrective action created successfully',
      data: {
        id: actionId,
        finding_id: findingId,
        description,
        assigned_to,
        due_date,
        status,
        created_by
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Create Corrective Action Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to create corrective action',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
