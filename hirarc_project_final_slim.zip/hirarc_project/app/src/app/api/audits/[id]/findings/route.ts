import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const auditPlanId = params.id;
  
  try {
    const { description, severity, status, photo_url, created_by } = await request.json();
    
    // Validate required fields
    if (!description || !severity || !status || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate severity
    if (!['critical', 'major', 'minor', 'observation'].includes(severity)) {
      return Response.json({
        status: 'error',
        message: 'Invalid severity'
      }, { status: 400 });
    }
    
    // Validate status
    if (!['open', 'in_progress', 'closed'].includes(status)) {
      return Response.json({
        status: 'error',
        message: 'Invalid status'
      }, { status: 400 });
    }
    
    // Check if audit plan exists
    const existingPlan = await env.DB.prepare(
      "SELECT id, status FROM Audit_Plans WHERE id = ?"
    ).bind(auditPlanId).first();
    
    if (!existingPlan) {
      return Response.json({
        status: 'error',
        message: 'Audit plan not found'
      }, { status: 404 });
    }
    
    // Check if audit plan is in a valid status for adding findings
    if (existingPlan.status === 'cancelled') {
      return Response.json({
        status: 'error',
        message: 'Cannot add findings to a cancelled audit plan'
      }, { status: 400 });
    }
    
    // If audit plan is still in 'planned' status, update it to 'in_progress'
    if (existingPlan.status === 'planned') {
      await env.DB.prepare(`
        UPDATE Audit_Plans
        SET status = 'in_progress', updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(auditPlanId).run();
    }
    
    // Insert new finding
    const result = await env.DB.prepare(`
      INSERT INTO Audit_Findings (audit_plan_id, description, severity, status, photo_url, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(auditPlanId, description, severity, status, photo_url || null, created_by).run();
    
    if (!result.success) {
      throw new Error('Failed to create audit finding');
    }
    
    // Get the inserted finding ID
    const findingId = result.meta?.last_row_id;
    
    // Check if finding is related to any HIRARC hazards
    const relatedHazards = await env.DB.prepare(`
      SELECT 
        h.id,
        h.description,
        h.hazard_type,
        a.id as activity_id,
        a.name as activity_name
      FROM Hazards h
      JOIN Activities a ON h.activity_id = a.id
      WHERE h.description LIKE ? AND a.department_id = (
        SELECT department_id FROM Audit_Plans WHERE id = ?
      )
      LIMIT 5
    `).bind(`%${description}%`, auditPlanId).all();
    
    return Response.json({
      status: 'success',
      message: 'Audit finding created successfully',
      data: {
        id: findingId,
        audit_plan_id: auditPlanId,
        description,
        severity,
        status,
        photo_url: photo_url || null,
        created_by,
        related_hazards: relatedHazards.results
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Create Audit Finding Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to create audit finding',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
