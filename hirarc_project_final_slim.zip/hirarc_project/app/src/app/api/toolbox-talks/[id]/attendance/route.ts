import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const toolboxTalkId = params.id;
  
  try {
    const { user_id, attendance, feedback } = await request.json();
    
    // Validate required fields
    if (!user_id) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Check if toolbox talk exists
    const existingTalk = await env.DB.prepare(
      "SELECT id FROM Toolbox_Talks WHERE id = ?"
    ).bind(toolboxTalkId).first();
    
    if (!existingTalk) {
      return Response.json({
        status: 'error',
        message: 'Toolbox talk not found'
      }, { status: 404 });
    }
    
    // Check if user exists
    const existingUser = await env.DB.prepare(
      "SELECT id FROM Users WHERE id = ?"
    ).bind(user_id).first();
    
    if (!existingUser) {
      return Response.json({
        status: 'error',
        message: 'User not found'
      }, { status: 404 });
    }
    
    // Check if attendance record already exists
    const existingAttendance = await env.DB.prepare(
      "SELECT id FROM Attendees WHERE toolbox_talk_id = ? AND user_id = ?"
    ).bind(toolboxTalkId, user_id).first();
    
    if (existingAttendance) {
      // Update existing attendance record
      const result = await env.DB.prepare(`
        UPDATE Attendees
        SET attendance = ?, feedback = ?, updated_at = CURRENT_TIMESTAMP
        WHERE toolbox_talk_id = ? AND user_id = ?
      `).bind(attendance || false, feedback || null, toolboxTalkId, user_id).run();
      
      if (!result.success) {
        throw new Error('Failed to update attendance record');
      }
      
      return Response.json({
        status: 'success',
        message: 'Attendance record updated successfully',
        data: {
          id: existingAttendance.id,
          toolbox_talk_id: toolboxTalkId,
          user_id,
          attendance: attendance || false,
          feedback: feedback || null
        }
      });
    } else {
      // Create new attendance record
      const result = await env.DB.prepare(`
        INSERT INTO Attendees (toolbox_talk_id, user_id, attendance, feedback, created_at, updated_at)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `).bind(toolboxTalkId, user_id, attendance || false, feedback || null).run();
      
      if (!result.success) {
        throw new Error('Failed to create attendance record');
      }
      
      // Get the inserted attendance ID
      const attendanceId = result.meta?.last_row_id;
      
      return Response.json({
        status: 'success',
        message: 'Attendance record created successfully',
        data: {
          id: attendanceId,
          toolbox_talk_id: toolboxTalkId,
          user_id,
          attendance: attendance || false,
          feedback: feedback || null
        }
      }, { status: 201 });
    }
    
  } catch (error) {
    console.error('Record Attendance Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to record attendance',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
