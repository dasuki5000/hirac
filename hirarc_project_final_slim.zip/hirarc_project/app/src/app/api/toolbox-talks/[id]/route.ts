import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const toolboxTalkId = params.id;
  
  try {
    // Get toolbox talk details
    const toolboxTalk = await env.DB.prepare(`
      SELECT 
        tt.id, 
        tt.title, 
        tt.description, 
        tt.date_time, 
        tt.location,
        tt.department_id,
        tt.created_by,
        tt.created_at,
        tt.updated_at,
        d.name as department_name,
        u.name as created_by_name
      FROM Toolbox_Talks tt
      JOIN Departments d ON tt.department_id = d.id
      JOIN Users u ON tt.created_by = u.id
      WHERE tt.id = ?
    `).bind(toolboxTalkId).first();
    
    if (!toolboxTalk) {
      return Response.json({
        status: 'error',
        message: 'Toolbox talk not found'
      }, { status: 404 });
    }
    
    // Get linked activities
    const activities = await env.DB.prepare(`
      SELECT 
        a.id,
        a.name,
        a.description,
        a.status
      FROM Activities a
      JOIN Talk_Activities ta ON a.id = ta.activity_id
      WHERE ta.toolbox_talk_id = ?
    `).bind(toolboxTalkId).all();
    
    // Get attendees
    const attendees = await env.DB.prepare(`
      SELECT 
        att.id,
        att.user_id,
        u.name as user_name,
        att.attendance,
        att.feedback,
        att.created_at
      FROM Attendees att
      JOIN Users u ON att.user_id = u.id
      WHERE att.toolbox_talk_id = ?
    `).bind(toolboxTalkId).all();
    
    return Response.json({
      status: 'success',
      data: {
        toolbox_talk: toolboxTalk,
        activities: activities.results,
        attendees: attendees.results
      }
    });
    
  } catch (error) {
    console.error('Get Toolbox Talk Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve toolbox talk details',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const toolboxTalkId = params.id;
  
  try {
    const { title, description, date_time, location, department_id, activities } = await request.json();
    
    // Validate required fields
    if (!title || !date_time || !department_id) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Check if toolbox talk exists
    const existingTalk = await env.DB.prepare(
      "SELECT id FROM Toolbox_Talks WHERE id = ?"
    ).bind(toolboxTalkId).first();
    
    if (!existingTalk) {
      return Response.json({
        status: 'error',
        message: 'Toolbox talk not found'
      }, { status: 404 });
    }
    
    // Start a transaction
    await env.DB.exec('BEGIN TRANSACTION');
    
    try {
      // Update toolbox talk
      const result = await env.DB.prepare(`
        UPDATE Toolbox_Talks
        SET title = ?, description = ?, date_time = ?, location = ?, department_id = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(title, description || null, date_time, location || null, department_id, toolboxTalkId).run();
      
      if (!result.success) {
        throw new Error('Failed to update toolbox talk');
      }
      
      // If activities are provided, update the links
      if (activities && Array.isArray(activities)) {
        // Remove existing links
        await env.DB.prepare(
          "DELETE FROM Talk_Activities WHERE toolbox_talk_id = ?"
        ).bind(toolboxTalkId).run();
        
        // Add new links
        for (const activityId of activities) {
          const linkResult = await env.DB.prepare(`
            INSERT INTO Talk_Activities (toolbox_talk_id, activity_id, created_at, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(toolboxTalkId, activityId).run();
          
          if (!linkResult.success) {
            throw new Error(`Failed to link activity ${activityId} to toolbox talk`);
          }
        }
      }
      
      // Commit the transaction
      await env.DB.exec('COMMIT');
      
      return Response.json({
        status: 'success',
        message: 'Toolbox talk updated successfully',
        data: {
          id: toolboxTalkId,
          title,
          description,
          date_time,
          location,
          department_id,
          activities: activities || []
        }
      });
      
    } catch (error) {
      // Rollback the transaction on error
      await env.DB.exec('ROLLBACK');
      throw error;
    }
    
  } catch (error) {
    console.error('Update Toolbox Talk Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to update toolbox talk',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const toolboxTalkId = params.id;
  
  try {
    // Check if toolbox talk exists
    const existingTalk = await env.DB.prepare(
      "SELECT id FROM Toolbox_Talks WHERE id = ?"
    ).bind(toolboxTalkId).first();
    
    if (!existingTalk) {
      return Response.json({
        status: 'error',
        message: 'Toolbox talk not found'
      }, { status: 404 });
    }
    
    // Start a transaction
    await env.DB.exec('BEGIN TRANSACTION');
    
    try {
      // Delete attendees
      await env.DB.prepare(
        "DELETE FROM Attendees WHERE toolbox_talk_id = ?"
      ).bind(toolboxTalkId).run();
      
      // Delete activity links
      await env.DB.prepare(
        "DELETE FROM Talk_Activities WHERE toolbox_talk_id = ?"
      ).bind(toolboxTalkId).run();
      
      // Delete toolbox talk
      const result = await env.DB.prepare(
        "DELETE FROM Toolbox_Talks WHERE id = ?"
      ).bind(toolboxTalkId).run();
      
      if (!result.success) {
        throw new Error('Failed to delete toolbox talk');
      }
      
      // Commit the transaction
      await env.DB.exec('COMMIT');
      
      return Response.json({
        status: 'success',
        message: 'Toolbox talk deleted successfully'
      });
      
    } catch (error) {
      // Rollback the transaction on error
      await env.DB.exec('ROLLBACK');
      throw error;
    }
    
  } catch (error) {
    console.error('Delete Toolbox Talk Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to delete toolbox talk',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
