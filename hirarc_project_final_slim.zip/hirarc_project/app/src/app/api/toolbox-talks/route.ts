import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(request: NextRequest) {
  const { env } = getCloudflareContext();
  const { searchParams } = new URL(request.url);
  
  try {
    // Get pagination parameters
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '10');
    const offset = (page - 1) * pageSize;
    
    // Get department filter if provided
    const departmentId = searchParams.get('department_id');
    
    // Build query based on parameters
    let query = `
      SELECT 
        tt.id, 
        tt.title, 
        tt.description, 
        tt.date_time, 
        tt.location,
        tt.created_at,
        d.name as department_name,
        u.name as created_by_name,
        (SELECT COUNT(*) FROM Attendees WHERE toolbox_talk_id = tt.id) as attendee_count,
        (SELECT COUNT(*) FROM Talk_Activities WHERE toolbox_talk_id = tt.id) as activity_count
      FROM Toolbox_Talks tt
      JOIN Departments d ON tt.department_id = d.id
      JOIN Users u ON tt.created_by = u.id
    `;
    
    const queryParams = [];
    
    if (departmentId) {
      query += " WHERE tt.department_id = ?";
      queryParams.push(departmentId);
    }
    
    query += " ORDER BY tt.date_time DESC LIMIT ? OFFSET ?";
    queryParams.push(pageSize, offset);
    
    // Execute query
    const stmt = env.DB.prepare(query);
    const bindResult = queryParams.length > 0 ? stmt.bind(...queryParams) : stmt;
    const toolboxTalks = await bindResult.all();
    
    // Get total count for pagination
    let countQuery = "SELECT COUNT(*) as count FROM Toolbox_Talks";
    if (departmentId) {
      countQuery += " WHERE department_id = ?";
    }
    
    const countStmt = env.DB.prepare(countQuery);
    const countBindResult = departmentId ? countStmt.bind(departmentId) : countStmt;
    const totalCount = await countBindResult.first();
    
    return Response.json({
      status: 'success',
      data: {
        toolbox_talks: toolboxTalks.results,
        pagination: {
          total: totalCount?.count || 0,
          page,
          pageSize,
          totalPages: Math.ceil((totalCount?.count || 0) / pageSize)
        }
      }
    });
    
  } catch (error) {
    console.error('Get Toolbox Talks Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve toolbox talks',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { title, description, date_time, location, department_id, created_by, activities } = await request.json();
    
    // Validate required fields
    if (!title || !date_time || !department_id || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Start a transaction
    await env.DB.exec('BEGIN TRANSACTION');
    
    try {
      // Insert new toolbox talk
      const result = await env.DB.prepare(`
        INSERT INTO Toolbox_Talks (title, description, date_time, location, department_id, created_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `).bind(title, description || null, date_time, location || null, department_id, created_by).run();
      
      if (!result.success) {
        throw new Error('Failed to create toolbox talk');
      }
      
      // Get the inserted toolbox talk ID
      const toolboxTalkId = result.meta?.last_row_id;
      
      // If activities are provided, link them to the toolbox talk
      if (activities && Array.isArray(activities) && activities.length > 0) {
        for (const activityId of activities) {
          const linkResult = await env.DB.prepare(`
            INSERT INTO Talk_Activities (toolbox_talk_id, activity_id, created_at, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(toolboxTalkId, activityId).run();
          
          if (!linkResult.success) {
            throw new Error(`Failed to link activity ${activityId} to toolbox talk`);
          }
        }
      }
      
      // Commit the transaction
      await env.DB.exec('COMMIT');
      
      return Response.json({
        status: 'success',
        message: 'Toolbox talk created successfully',
        data: {
          id: toolboxTalkId,
          title,
          description,
          date_time,
          location,
          department_id,
          created_by,
          activities: activities || []
        }
      }, { status: 201 });
      
    } catch (error) {
      // Rollback the transaction on error
      await env.DB.exec('ROLLBACK');
      throw error;
    }
    
  } catch (error) {
    console.error('Create Toolbox Talk Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to create toolbox talk',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
