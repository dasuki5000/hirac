import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    // Test database connection
    const dbTest = await env.DB.prepare(
      "SELECT 'Database connection successful' as message"
    ).first();
    
    // Get counts of key entities
    const activityCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Activities"
    ).first();
    
    const hazardCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Hazards"
    ).first();
    
    const userCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Users"
    ).first();
    
    return Response.json({
      status: "success",
      message: "API is running with database connection",
      database_status: dbTest?.message || "Unknown",
      counts: {
        activities: activityCount?.count || 0,
        hazards: hazardCount?.count || 0,
        users: userCount?.count || 0
      },
      version: "1.0.0",
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Database Test Error:', error);
    return Response.json({
      status: "error",
      message: "API is running but database connection failed",
      error: error instanceof Error ? error.message : String(error),
      version: "1.0.0",
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}
