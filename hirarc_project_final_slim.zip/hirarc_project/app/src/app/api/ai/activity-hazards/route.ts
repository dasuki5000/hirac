import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { activity_name, activity_description, department_id } = await request.json();
    
    // Validate required fields
    if (!activity_name || !department_id) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Find similar activities to suggest hazards
    const similarActivities = await env.DB.prepare(`
      SELECT id, name
      FROM Activities
      WHERE 
        name LIKE ? OR
        description LIKE ?
      LIMIT 5
    `).bind(`%${activity_name}%`, `%${activity_description || activity_name}%`).all();
    
    const activityIds = similarActivities.results.map(a => a.id);
    
    // If no similar activities found, return empty suggestions
    if (activityIds.length === 0) {
      return Response.json({
        status: 'success',
        data: {
          suggestions: [],
          message: "No similar activities found to suggest hazards"
        }
      });
    }
    
    // Get common hazards from similar activities
    const placeholders = activityIds.map(() => '?').join(',');
    const hazards = await env.DB.prepare(`
      SELECT 
        h.description, 
        h.hazard_type,
        COUNT(*) as occurrence_count,
        AVG(ra.risk_level) as avg_risk_level
      FROM Hazards h
      LEFT JOIN Risk_Assessments ra ON h.id = ra.hazard_id
      WHERE h.activity_id IN (${placeholders})
      GROUP BY h.description, h.hazard_type
      ORDER BY occurrence_count DESC, avg_risk_level DESC
      LIMIT 10
    `).bind(...activityIds).all();
    
    return Response.json({
      status: 'success',
      data: {
        suggestions: hazards.results,
        similar_activities: similarActivities.results,
        message: "Hazards suggested based on similar activities"
      }
    });
    
  } catch (error) {
    console.error('AI Activity Hazard Suggestion Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to generate hazard suggestions',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
