import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(request: NextRequest) {
  const { env } = getCloudflareContext();
  const { searchParams } = new URL(request.url);
  
  try {
    // Get query parameters
    const activityName = searchParams.get('activity') || '';
    const hazardType = searchParams.get('type') || '';
    
    // Build query based on parameters
    let query = `
      SELECT 
        h.id, 
        h.description, 
        h.hazard_type,
        a.id as activity_id,
        a.name as activity_name,
        COUNT(cm.id) as control_count
      FROM Hazards h
      JOIN Activities a ON h.activity_id = a.id
      LEFT JOIN Control_Measures cm ON h.id = cm.hazard_id
    `;
    
    const queryParams = [];
    const whereConditions = [];
    
    if (activityName) {
      whereConditions.push("a.name LIKE ?");
      queryParams.push(`%${activityName}%`);
    }
    
    if (hazardType && ['health', 'safety', 'environmental'].includes(hazardType)) {
      whereConditions.push("h.hazard_type = ?");
      queryParams.push(hazardType);
    }
    
    if (whereConditions.length > 0) {
      query += " WHERE " + whereConditions.join(" AND ");
    }
    
    query += " GROUP BY h.id ORDER BY h.hazard_type, h.description";
    
    // Execute query
    const stmt = env.DB.prepare(query);
    const bindResult = queryParams.length > 0 ? stmt.bind(...queryParams) : stmt;
    const hazards = await bindResult.all();
    
    return Response.json({
      status: 'success',
      data: {
        hazards: hazards.results
      }
    });
    
  } catch (error) {
    console.error('AI Suggestion Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve hazard suggestions',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
