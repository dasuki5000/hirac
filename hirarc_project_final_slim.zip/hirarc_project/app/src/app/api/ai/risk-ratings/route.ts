import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { hazard_description, hazard_type } = await request.json();
    
    // Validate required fields
    if (!hazard_description || !hazard_type) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate hazard type
    if (!['health', 'safety', 'environmental'].includes(hazard_type)) {
      return Response.json({
        status: 'error',
        message: 'Invalid hazard type'
      }, { status: 400 });
    }
    
    // Find similar hazards to suggest risk ratings
    const similarHazards = await env.DB.prepare(`
      SELECT 
        h.id,
        h.description,
        ra.likelihood,
        ra.severity,
        ra.risk_level
      FROM Hazards h
      JOIN Risk_Assessments ra ON h.id = ra.hazard_id
      WHERE 
        h.hazard_type = ? AND
        h.description LIKE ?
      ORDER BY ra.created_at DESC
      LIMIT 10
    `).bind(hazard_type, `%${hazard_description}%`).all();
    
    // Calculate average likelihood and severity if similar hazards found
    let avgLikelihood = 0;
    let avgSeverity = 0;
    let recommendedLikelihood = 3; // Default middle value
    let recommendedSeverity = 3; // Default middle value
    
    if (similarHazards.results.length > 0) {
      const sum = similarHazards.results.reduce((acc, curr) => {
        return {
          likelihood: acc.likelihood + curr.likelihood,
          severity: acc.severity + curr.severity
        };
      }, { likelihood: 0, severity: 0 });
      
      avgLikelihood = Math.round(sum.likelihood / similarHazards.results.length);
      avgSeverity = Math.round(sum.severity / similarHazards.results.length);
      
      recommendedLikelihood = avgLikelihood;
      recommendedSeverity = avgSeverity;
    }
    
    return Response.json({
      status: 'success',
      data: {
        similar_hazards: similarHazards.results,
        recommended_rating: {
          likelihood: recommendedLikelihood,
          severity: recommendedSeverity,
          risk_level: recommendedLikelihood * recommendedSeverity
        },
        message: similarHazards.results.length > 0 
          ? "Risk rating suggested based on similar hazards" 
          : "Default risk rating suggested (no similar hazards found)"
      }
    });
    
  } catch (error) {
    console.error('AI Risk Rating Suggestion Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to generate risk rating suggestions',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
