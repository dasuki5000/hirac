import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { activity_id, planned_date } = await request.json();
    
    // Validate required fields
    if (!activity_id || !planned_date) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Get activity details
    const activity = await env.DB.prepare(`
      SELECT id, name, description, department_id
      FROM Activities
      WHERE id = ?
    `).bind(activity_id).first();
    
    if (!activity) {
      return Response.json({
        status: 'error',
        message: 'Activity not found'
      }, { status: 404 });
    }
    
    // Get hazards and their controls for this activity
    const hazardsWithControls = await env.DB.prepare(`
      SELECT 
        h.id as hazard_id,
        h.description as hazard_description,
        h.hazard_type,
        ra.risk_level,
        cm.id as control_id,
        cm.description as control_description,
        cm.control_type,
        cm.status
      FROM Hazards h
      LEFT JOIN Risk_Assessments ra ON h.id = ra.hazard_id
      LEFT JOIN Control_Measures cm ON h.id = cm.hazard_id
      WHERE h.activity_id = ?
      ORDER BY ra.risk_level DESC, cm.control_type
    `).bind(activity_id).all();
    
    // Generate toolbox talk content
    const talkTitle = `Safety Briefing: ${activity.name}`;
    const hazardsByType = {};
    const controlsByHazard = {};
    
    hazardsWithControls.results.forEach(item => {
      // Group hazards by type
      if (!hazardsByType[item.hazard_type]) {
        hazardsByType[item.hazard_type] = [];
      }
      
      if (!hazardsByType[item.hazard_type].includes(item.hazard_description)) {
        hazardsByType[item.hazard_type].push(item.hazard_description);
      }
      
      // Group controls by hazard
      if (item.control_id) {
        if (!controlsByHazard[item.hazard_id]) {
          controlsByHazard[item.hazard_id] = [];
        }
        
        controlsByHazard[item.hazard_id].push({
          description: item.control_description,
          type: item.control_type,
          status: item.status
        });
      }
    });
    
    // Format content for toolbox talk
    let talkContent = `# ${talkTitle}\n\n`;
    talkContent += `## Activity Description\n${activity.description || activity.name}\n\n`;
    talkContent += `## Date: ${planned_date}\n\n`;
    
    // Add hazards section
    talkContent += `## Hazards Identified\n\n`;
    
    for (const [type, hazards] of Object.entries(hazardsByType)) {
      talkContent += `### ${type.charAt(0).toUpperCase() + type.slice(1)} Hazards\n`;
      hazards.forEach(hazard => {
        talkContent += `- ${hazard}\n`;
      });
      talkContent += '\n';
    }
    
    // Add controls section
    talkContent += `## Control Measures\n\n`;
    
    for (const [hazardId, controls] of Object.entries(controlsByHazard)) {
      const hazard = hazardsWithControls.results.find(h => h.hazard_id == hazardId);
      talkContent += `### For ${hazard.hazard_description}\n`;
      
      // Group controls by type
      const controlsByType = {};
      controls.forEach(control => {
        if (!controlsByType[control.type]) {
          controlsByType[control.type] = [];
        }
        controlsByType[control.type].push(control);
      });
      
      // Order control types by hierarchy
      const controlTypeOrder = ['elimination', 'substitution', 'engineering', 'administrative', 'ppe'];
      
      controlTypeOrder.forEach(type => {
        if (controlsByType[type]) {
          const typeName = type.charAt(0).toUpperCase() + type.slice(1);
          controlsByType[type].forEach(control => {
            talkContent += `- **${typeName}**: ${control.description}\n`;
          });
        }
      });
      
      talkContent += '\n';
    }
    
    // Add safety reminders
    talkContent += `## Safety Reminders\n\n`;
    talkContent += `- Always wear appropriate PPE for the task\n`;
    talkContent += `- Report any unsafe conditions immediately\n`;
    talkContent += `- Follow all safety procedures and work instructions\n`;
    talkContent += `- Ask questions if you are unsure about any aspect of the work\n\n`;
    
    // Add attendance section
    talkContent += `## Attendance\n\n`;
    talkContent += `| Name | Signature | Comments |\n`;
    talkContent += `|------|-----------|----------|\n`;
    talkContent += `|      |           |          |\n`;
    talkContent += `|      |           |          |\n`;
    talkContent += `|      |           |          |\n`;
    
    return Response.json({
      status: 'success',
      data: {
        title: talkTitle,
        content: talkContent,
        activity: activity,
        hazards_count: Object.values(hazardsByType).flat().length,
        controls_count: Object.values(controlsByHazard).flat().length,
        planned_date: planned_date
      }
    });
    
  } catch (error) {
    console.error('AI Toolbox Talk Generation Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to generate toolbox talk content',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
