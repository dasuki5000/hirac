import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { hazard_id, hazard_type, risk_level } = await request.json();
    
    // Validate required fields
    if (!hazard_id || !hazard_type || !risk_level) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate hazard type
    if (!['health', 'safety', 'environmental'].includes(hazard_type)) {
      return Response.json({
        status: 'error',
        message: 'Invalid hazard type'
      }, { status: 400 });
    }
    
    // Get similar control measures based on hazard type and risk level
    const controlMeasures = await env.DB.prepare(`
      SELECT 
        cm.description, 
        cm.control_type,
        COUNT(*) as usage_count
      FROM Control_Measures cm
      JOIN Hazards h ON cm.hazard_id = h.id
      JOIN Risk_Assessments ra ON cm.assessment_id = ra.id
      WHERE 
        h.hazard_type = ? AND
        h.id != ? AND
        ra.risk_level >= ?
      GROUP BY cm.description, cm.control_type
      ORDER BY 
        CASE cm.control_type
          WHEN 'elimination' THEN 1
          WHEN 'substitution' THEN 2
          WHEN 'engineering' THEN 3
          WHEN 'administrative' THEN 4
          WHEN 'ppe' THEN 5
        END,
        usage_count DESC
      LIMIT 10
    `).bind(hazard_type, hazard_id, risk_level).all();
    
    return Response.json({
      status: 'success',
      data: {
        suggestions: controlMeasures.results,
        message: "Control measures suggested based on similar hazards and risk levels"
      }
    });
    
  } catch (error) {
    console.error('AI Control Suggestion Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to generate control measure suggestions',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
