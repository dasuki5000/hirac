import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(request: NextRequest) {
  const { env } = getCloudflareContext();
  const { searchParams } = new URL(request.url);
  
  try {
    // Get pagination parameters
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '10');
    const offset = (page - 1) * pageSize;
    
    // Get activities with department info
    const activities = await env.DB.prepare(`
      SELECT 
        a.id, 
        a.name, 
        a.description, 
        a.status,
        a.created_at,
        d.name as department_name,
        u.name as created_by_name,
        (SELECT COUNT(*) FROM Hazards WHERE activity_id = a.id) as hazard_count
      FROM Activities a
      JOIN Departments d ON a.department_id = d.id
      JOIN Users u ON a.created_by = u.id
      ORDER BY a.created_at DESC
      LIMIT ? OFFSET ?
    `).bind(pageSize, offset).all();
    
    // Get total count for pagination
    const totalCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Activities"
    ).first();
    
    return Response.json({
      status: 'success',
      data: {
        activities: activities.results,
        pagination: {
          total: totalCount?.count || 0,
          page,
          pageSize,
          totalPages: Math.ceil((totalCount?.count || 0) / pageSize)
        }
      }
    });
    
  } catch (error) {
    console.error('Get Activities Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve activities',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const { env } = getCloudflareContext();
  
  try {
    const { name, description, department_id, created_by } = await request.json();
    
    // Validate required fields
    if (!name || !department_id || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Insert new activity
    const result = await env.DB.prepare(`
      INSERT INTO Activities (name, description, department_id, created_by, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(name, description || null, department_id, created_by).run();
    
    if (!result.success) {
      throw new Error('Failed to create activity');
    }
    
    // Get the inserted activity ID
    const activityId = result.meta?.last_row_id;
    
    return Response.json({
      status: 'success',
      message: 'Activity created successfully',
      data: {
        id: activityId,
        name,
        description,
        department_id,
        created_by,
        status: 'active'
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Create Activity Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to create activity',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
