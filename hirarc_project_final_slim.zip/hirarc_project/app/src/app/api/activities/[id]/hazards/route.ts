import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(request: NextRequest) {
  const { env } = getCloudflareContext();
  const { searchParams } = new URL(request.url);
  
  try {
    // Get pagination parameters
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '10');
    const offset = (page - 1) * pageSize;
    
    // Get hazards for this activity
    const hazards = await env.DB.prepare(`
      SELECT 
        h.id, 
        h.description, 
        h.hazard_type,
        h.suggested_by_ai,
        h.created_at,
        u.name as created_by_name,
        (
          SELECT MAX(risk_level) 
          FROM Risk_Assessments 
          WHERE hazard_id = h.id
        ) as max_risk_level
      FROM Hazards h
      JOIN Users u ON h.created_by = u.id
      WHERE h.activity_id = ?
      ORDER BY max_risk_level DESC NULLS LAST, h.created_at DESC
      LIMIT ? OFFSET ?
    `).bind(params.id, pageSize, offset).all();
    
    // Get total count for pagination
    const totalCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Hazards WHERE activity_id = ?"
    ).bind(params.id).first();
    
    return Response.json({
      status: 'success',
      data: {
        hazards: hazards.results,
        pagination: {
          total: totalCount?.count || 0,
          page,
          pageSize,
          totalPages: Math.ceil((totalCount?.count || 0) / pageSize)
        }
      }
    });
    
  } catch (error) {
    console.error('Get Hazards Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve hazards',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const activityId = params.id;
  
  try {
    const { description, hazard_type, suggested_by_ai, created_by } = await request.json();
    
    // Validate required fields
    if (!description || !hazard_type || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate hazard type
    if (!['health', 'safety', 'environmental'].includes(hazard_type)) {
      return Response.json({
        status: 'error',
        message: 'Invalid hazard type'
      }, { status: 400 });
    }
    
    // Check if activity exists
    const existingActivity = await env.DB.prepare(
      "SELECT id FROM Activities WHERE id = ?"
    ).bind(activityId).first();
    
    if (!existingActivity) {
      return Response.json({
        status: 'error',
        message: 'Activity not found'
      }, { status: 404 });
    }
    
    // Insert new hazard
    const result = await env.DB.prepare(`
      INSERT INTO Hazards (activity_id, description, hazard_type, suggested_by_ai, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(activityId, description, hazard_type, suggested_by_ai || false, created_by).run();
    
    if (!result.success) {
      throw new Error('Failed to create hazard');
    }
    
    // Get the inserted hazard ID
    const hazardId = result.meta?.last_row_id;
    
    return Response.json({
      status: 'success',
      message: 'Hazard created successfully',
      data: {
        id: hazardId,
        activity_id: activityId,
        description,
        hazard_type,
        suggested_by_ai: suggested_by_ai || false,
        created_by
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Create Hazard Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to create hazard',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
