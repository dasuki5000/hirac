import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string, hazardId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: activityId, hazardId } = params;
  
  try {
    const { likelihood, severity, created_by } = await request.json();
    
    // Validate required fields
    if (!likelihood || !severity || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate likelihood and severity (1-5)
    if (likelihood < 1 || likelihood > 5 || severity < 1 || severity > 5) {
      return Response.json({
        status: 'error',
        message: 'Likelihood and severity must be between 1 and 5'
      }, { status: 400 });
    }
    
    // Check if hazard exists
    const existingHazard = await env.DB.prepare(
      "SELECT id FROM Hazards WHERE id = ? AND activity_id = ?"
    ).bind(hazardId, activityId).first();
    
    if (!existingHazard) {
      return Response.json({
        status: 'error',
        message: 'Hazard not found'
      }, { status: 404 });
    }
    
    // Insert new risk assessment
    const result = await env.DB.prepare(`
      INSERT INTO Risk_Assessments (hazard_id, likelihood, severity, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(hazardId, likelihood, severity, created_by).run();
    
    if (!result.success) {
      throw new Error('Failed to create risk assessment');
    }
    
    // Get the inserted risk assessment ID
    const assessmentId = result.meta?.last_row_id;
    
    // Calculate risk level
    const riskLevel = likelihood * severity;
    
    return Response.json({
      status: 'success',
      message: 'Risk assessment created successfully',
      data: {
        id: assessmentId,
        hazard_id: hazardId,
        likelihood,
        severity,
        risk_level: riskLevel,
        created_by
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Create Risk Assessment Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to create risk assessment',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
