import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string, hazardId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: activityId, hazardId } = params;
  
  try {
    const { description, control_type, status, assessment_id, suggested_by_ai, created_by } = await request.json();
    
    // Validate required fields
    if (!description || !control_type || !status || !assessment_id || !created_by) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate control type
    if (!['elimination', 'substitution', 'engineering', 'administrative', 'ppe'].includes(control_type)) {
      return Response.json({
        status: 'error',
        message: 'Invalid control type'
      }, { status: 400 });
    }
    
    // Validate status
    if (!['planned', 'implemented', 'verified', 'ineffective'].includes(status)) {
      return Response.json({
        status: 'error',
        message: 'Invalid status'
      }, { status: 400 });
    }
    
    // Check if hazard exists
    const existingHazard = await env.DB.prepare(
      "SELECT id FROM Hazards WHERE id = ? AND activity_id = ?"
    ).bind(hazardId, activityId).first();
    
    if (!existingHazard) {
      return Response.json({
        status: 'error',
        message: 'Hazard not found'
      }, { status: 404 });
    }
    
    // Check if assessment exists
    const existingAssessment = await env.DB.prepare(
      "SELECT id FROM Risk_Assessments WHERE id = ? AND hazard_id = ?"
    ).bind(assessment_id, hazardId).first();
    
    if (!existingAssessment) {
      return Response.json({
        status: 'error',
        message: 'Risk assessment not found'
      }, { status: 404 });
    }
    
    // Insert new control measure
    const result = await env.DB.prepare(`
      INSERT INTO Control_Measures (hazard_id, assessment_id, description, control_type, status, suggested_by_ai, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(hazardId, assessment_id, description, control_type, status, suggested_by_ai || false, created_by).run();
    
    if (!result.success) {
      throw new Error('Failed to create control measure');
    }
    
    // Get the inserted control measure ID
    const controlId = result.meta?.last_row_id;
    
    return Response.json({
      status: 'success',
      message: 'Control measure created successfully',
      data: {
        id: controlId,
        hazard_id: hazardId,
        assessment_id,
        description,
        control_type,
        status,
        suggested_by_ai: suggested_by_ai || false,
        created_by
      }
    }, { status: 201 });
    
  } catch (error) {
    console.error('Create Control Measure Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to create control measure',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
