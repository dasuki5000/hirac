import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string, hazardId: string, controlId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: activityId, hazardId, controlId } = params;
  
  try {
    // Get control measure details
    const control = await env.DB.prepare(`
      SELECT 
        cm.id, 
        cm.hazard_id,
        cm.assessment_id,
        cm.description, 
        cm.control_type,
        cm.status,
        cm.suggested_by_ai,
        cm.created_by,
        cm.created_at,
        cm.updated_at,
        u.name as created_by_name,
        h.description as hazard_description,
        ra.risk_level
      FROM Control_Measures cm
      JOIN Users u ON cm.created_by = u.id
      JOIN Hazards h ON cm.hazard_id = h.id
      JOIN Risk_Assessments ra ON cm.assessment_id = ra.id
      WHERE cm.id = ? AND cm.hazard_id = ? AND h.activity_id = ?
    `).bind(controlId, hazardId, activityId).first();
    
    if (!control) {
      return Response.json({
        status: 'error',
        message: 'Control measure not found'
      }, { status: 404 });
    }
    
    return Response.json({
      status: 'success',
      data: {
        control
      }
    });
    
  } catch (error) {
    console.error('Get Control Measure Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve control measure details',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string, hazardId: string, controlId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: activityId, hazardId, controlId } = params;
  
  try {
    const { description, control_type, status } = await request.json();
    
    // Validate required fields
    if (!description || !control_type || !status) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate control type
    if (!['elimination', 'substitution', 'engineering', 'administrative', 'ppe'].includes(control_type)) {
      return Response.json({
        status: 'error',
        message: 'Invalid control type'
      }, { status: 400 });
    }
    
    // Validate status
    if (!['planned', 'implemented', 'verified', 'ineffective'].includes(status)) {
      return Response.json({
        status: 'error',
        message: 'Invalid status'
      }, { status: 400 });
    }
    
    // Check if control measure exists
    const existingControl = await env.DB.prepare(`
      SELECT cm.id 
      FROM Control_Measures cm
      JOIN Hazards h ON cm.hazard_id = h.id
      WHERE cm.id = ? AND cm.hazard_id = ? AND h.activity_id = ?
    `).bind(controlId, hazardId, activityId).first();
    
    if (!existingControl) {
      return Response.json({
        status: 'error',
        message: 'Control measure not found'
      }, { status: 404 });
    }
    
    // Update control measure
    const result = await env.DB.prepare(`
      UPDATE Control_Measures
      SET description = ?, control_type = ?, status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND hazard_id = ?
    `).bind(description, control_type, status, controlId, hazardId).run();
    
    if (!result.success) {
      throw new Error('Failed to update control measure');
    }
    
    return Response.json({
      status: 'success',
      message: 'Control measure updated successfully',
      data: {
        id: controlId,
        hazard_id: hazardId,
        description,
        control_type,
        status
      }
    });
    
  } catch (error) {
    console.error('Update Control Measure Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to update control measure',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string, hazardId: string, controlId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: activityId, hazardId, controlId } = params;
  
  try {
    // Check if control measure exists
    const existingControl = await env.DB.prepare(`
      SELECT cm.id 
      FROM Control_Measures cm
      JOIN Hazards h ON cm.hazard_id = h.id
      WHERE cm.id = ? AND cm.hazard_id = ? AND h.activity_id = ?
    `).bind(controlId, hazardId, activityId).first();
    
    if (!existingControl) {
      return Response.json({
        status: 'error',
        message: 'Control measure not found'
      }, { status: 404 });
    }
    
    // Check if control is referenced in permit hazards
    const permitCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Permit_Hazards WHERE control_id = ?"
    ).bind(controlId).first();
    
    if (permitCount && permitCount.count > 0) {
      return Response.json({
        status: 'error',
        message: 'Cannot delete control measure referenced in permit to work'
      }, { status: 409 });
    }
    
    // Delete control measure
    const result = await env.DB.prepare(
      "DELETE FROM Control_Measures WHERE id = ? AND hazard_id = ?"
    ).bind(controlId, hazardId).run();
    
    if (!result.success) {
      throw new Error('Failed to delete control measure');
    }
    
    return Response.json({
      status: 'success',
      message: 'Control measure deleted successfully'
    });
    
  } catch (error) {
    console.error('Delete Control Measure Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to delete control measure',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
