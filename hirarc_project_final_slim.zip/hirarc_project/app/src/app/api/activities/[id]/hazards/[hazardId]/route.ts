import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string, hazardId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: activityId, hazardId } = params;
  
  try {
    // Get hazard details
    const hazard = await env.DB.prepare(`
      SELECT 
        h.id, 
        h.activity_id,
        h.description, 
        h.hazard_type,
        h.suggested_by_ai,
        h.created_by,
        h.created_at,
        h.updated_at,
        u.name as created_by_name,
        a.name as activity_name
      FROM Hazards h
      JOIN Users u ON h.created_by = u.id
      JOIN Activities a ON h.activity_id = a.id
      WHERE h.id = ? AND h.activity_id = ?
    `).bind(hazardId, activityId).first();
    
    if (!hazard) {
      return Response.json({
        status: 'error',
        message: 'Hazard not found'
      }, { status: 404 });
    }
    
    // Get risk assessments for this hazard
    const riskAssessments = await env.DB.prepare(`
      SELECT 
        ra.id,
        ra.likelihood,
        ra.severity,
        ra.risk_level,
        ra.created_at,
        u.name as created_by_name
      FROM Risk_Assessments ra
      JOIN Users u ON ra.created_by = u.id
      WHERE ra.hazard_id = ?
      ORDER BY ra.created_at DESC
    `).bind(hazardId).all();
    
    // Get control measures for this hazard
    const controlMeasures = await env.DB.prepare(`
      SELECT 
        cm.id,
        cm.description,
        cm.control_type,
        cm.status,
        cm.suggested_by_ai,
        cm.created_at,
        u.name as created_by_name
      FROM Control_Measures cm
      JOIN Users u ON cm.created_by = u.id
      WHERE cm.hazard_id = ?
      ORDER BY 
        CASE cm.control_type
          WHEN 'elimination' THEN 1
          WHEN 'substitution' THEN 2
          WHEN 'engineering' THEN 3
          WHEN 'administrative' THEN 4
          WHEN 'ppe' THEN 5
        END,
        cm.created_at DESC
    `).bind(hazardId).all();
    
    return Response.json({
      status: 'success',
      data: {
        hazard,
        riskAssessments: riskAssessments.results,
        controlMeasures: controlMeasures.results
      }
    });
    
  } catch (error) {
    console.error('Get Hazard Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve hazard details',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string, hazardId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: activityId, hazardId } = params;
  
  try {
    const { description, hazard_type } = await request.json();
    
    // Validate required fields
    if (!description || !hazard_type) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate hazard type
    if (!['health', 'safety', 'environmental'].includes(hazard_type)) {
      return Response.json({
        status: 'error',
        message: 'Invalid hazard type'
      }, { status: 400 });
    }
    
    // Check if hazard exists
    const existingHazard = await env.DB.prepare(
      "SELECT id FROM Hazards WHERE id = ? AND activity_id = ?"
    ).bind(hazardId, activityId).first();
    
    if (!existingHazard) {
      return Response.json({
        status: 'error',
        message: 'Hazard not found'
      }, { status: 404 });
    }
    
    // Update hazard
    const result = await env.DB.prepare(`
      UPDATE Hazards
      SET description = ?, hazard_type = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND activity_id = ?
    `).bind(description, hazard_type, hazardId, activityId).run();
    
    if (!result.success) {
      throw new Error('Failed to update hazard');
    }
    
    return Response.json({
      status: 'success',
      message: 'Hazard updated successfully',
      data: {
        id: hazardId,
        activity_id: activityId,
        description,
        hazard_type
      }
    });
    
  } catch (error) {
    console.error('Update Hazard Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to update hazard',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string, hazardId: string } }
) {
  const { env } = getCloudflareContext();
  const { id: activityId, hazardId } = params;
  
  try {
    // Check if hazard exists
    const existingHazard = await env.DB.prepare(
      "SELECT id FROM Hazards WHERE id = ? AND activity_id = ?"
    ).bind(hazardId, activityId).first();
    
    if (!existingHazard) {
      return Response.json({
        status: 'error',
        message: 'Hazard not found'
      }, { status: 404 });
    }
    
    // Check if hazard has risk assessments or control measures
    const assessmentCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Risk_Assessments WHERE hazard_id = ?"
    ).bind(hazardId).first();
    
    const controlCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Control_Measures WHERE hazard_id = ?"
    ).bind(hazardId).first();
    
    if ((assessmentCount && assessmentCount.count > 0) || 
        (controlCount && controlCount.count > 0)) {
      return Response.json({
        status: 'error',
        message: 'Cannot delete hazard with associated risk assessments or control measures'
      }, { status: 409 });
    }
    
    // Delete hazard
    const result = await env.DB.prepare(
      "DELETE FROM Hazards WHERE id = ? AND activity_id = ?"
    ).bind(hazardId, activityId).run();
    
    if (!result.success) {
      throw new Error('Failed to delete hazard');
    }
    
    return Response.json({
      status: 'success',
      message: 'Hazard deleted successfully'
    });
    
  } catch (error) {
    console.error('Delete Hazard Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to delete hazard',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
