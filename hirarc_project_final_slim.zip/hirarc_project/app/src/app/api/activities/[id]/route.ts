import { NextRequest } from 'next/server';
import { getCloudflareContext } from '@/lib/cloudflare';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const activityId = params.id;
  
  try {
    // Get activity details
    const activity = await env.DB.prepare(`
      SELECT 
        a.id, 
        a.name, 
        a.description, 
        a.status,
        a.department_id,
        a.created_by,
        a.created_at,
        a.updated_at,
        d.name as department_name,
        u.name as created_by_name
      FROM Activities a
      JOIN Departments d ON a.department_id = d.id
      JOIN Users u ON a.created_by = u.id
      WHERE a.id = ?
    `).bind(activityId).first();
    
    if (!activity) {
      return Response.json({
        status: 'error',
        message: 'Activity not found'
      }, { status: 404 });
    }
    
    // Get hazards for this activity
    const hazards = await env.DB.prepare(`
      SELECT 
        h.id,
        h.description,
        h.hazard_type,
        h.suggested_by_ai,
        h.created_at,
        u.name as created_by_name,
        (
          SELECT MAX(risk_level) 
          FROM Risk_Assessments 
          WHERE hazard_id = h.id
        ) as max_risk_level
      FROM Hazards h
      JOIN Users u ON h.created_by = u.id
      WHERE h.activity_id = ?
      ORDER BY max_risk_level DESC NULLS LAST, h.created_at DESC
    `).bind(activityId).all();
    
    return Response.json({
      status: 'success',
      data: {
        activity,
        hazards: hazards.results
      }
    });
    
  } catch (error) {
    console.error('Get Activity Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to retrieve activity details',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const activityId = params.id;
  
  try {
    const { name, description, status, department_id } = await request.json();
    
    // Validate required fields
    if (!name || !status || !department_id) {
      return Response.json({
        status: 'error',
        message: 'Missing required fields'
      }, { status: 400 });
    }
    
    // Validate status
    if (!['active', 'inactive', 'archived'].includes(status)) {
      return Response.json({
        status: 'error',
        message: 'Invalid status'
      }, { status: 400 });
    }
    
    // Check if activity exists
    const existingActivity = await env.DB.prepare(
      "SELECT id FROM Activities WHERE id = ?"
    ).bind(activityId).first();
    
    if (!existingActivity) {
      return Response.json({
        status: 'error',
        message: 'Activity not found'
      }, { status: 404 });
    }
    
    // Update activity
    const result = await env.DB.prepare(`
      UPDATE Activities
      SET name = ?, description = ?, status = ?, department_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(name, description || null, status, department_id, activityId).run();
    
    if (!result.success) {
      throw new Error('Failed to update activity');
    }
    
    return Response.json({
      status: 'success',
      message: 'Activity updated successfully',
      data: {
        id: activityId,
        name,
        description,
        status,
        department_id
      }
    });
    
  } catch (error) {
    console.error('Update Activity Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to update activity',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { env } = getCloudflareContext();
  const activityId = params.id;
  
  try {
    // Check if activity exists
    const existingActivity = await env.DB.prepare(
      "SELECT id FROM Activities WHERE id = ?"
    ).bind(activityId).first();
    
    if (!existingActivity) {
      return Response.json({
        status: 'error',
        message: 'Activity not found'
      }, { status: 404 });
    }
    
    // Check if activity has hazards
    const hazardCount = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM Hazards WHERE activity_id = ?"
    ).bind(activityId).first();
    
    if (hazardCount && hazardCount.count > 0) {
      // Instead of deleting, archive the activity
      const result = await env.DB.prepare(`
        UPDATE Activities
        SET status = 'archived', updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(activityId).run();
      
      if (!result.success) {
        throw new Error('Failed to archive activity');
      }
      
      return Response.json({
        status: 'success',
        message: 'Activity has associated hazards and has been archived instead of deleted'
      });
    } else {
      // Delete activity if no hazards
      const result = await env.DB.prepare(
        "DELETE FROM Activities WHERE id = ?"
      ).bind(activityId).run();
      
      if (!result.success) {
        throw new Error('Failed to delete activity');
      }
      
      return Response.json({
        status: 'success',
        message: 'Activity deleted successfully'
      });
    }
    
  } catch (error) {
    console.error('Delete Activity Error:', error);
    return Response.json({
      status: 'error',
      message: 'Failed to delete activity',
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
