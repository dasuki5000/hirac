import { getCloudflareContext } from '@/lib/cloudflare';

export interface CloudflareContext {
  env: {
    DB: D1Database;
    ASSETS: any;
  };
  ctx: ExecutionContext;
}

export function getCloudflareContext(): CloudflareContext {
  // @ts-ignore - Cloudflare Workers runtime provides these globals
  const env = process.env.NODE_ENV === 'development' ? 
    // @ts-ignore
    { DB: __D1_BETA__DB, ASSETS: __STATIC_CONTENT } : 
    // @ts-ignore
    { DB: DB, ASSETS: ASSETS };
  
  // @ts-ignore
  const ctx = process.env.NODE_ENV === 'development' ? __CLOUDFLARE_WORKER_CONTEXT__ : null;
  
  return { env, ctx };
}
