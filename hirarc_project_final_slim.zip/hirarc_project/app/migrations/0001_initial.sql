-- Migration number: 0001 	 2025-04-22
-- HIRARC Web Application Initial Database Schema

-- Drop existing tables if they exist
DROP TABLE IF EXISTS Permit_Hazards;
DROP TABLE IF EXISTS Permit_Approvals;
DROP TABLE IF EXISTS Permit_Requests;
DROP TABLE IF EXISTS Corrective_Actions;
DROP TABLE IF EXISTS Audit_Findings;
DROP TABLE IF EXISTS Audit_Plans;
DROP TABLE IF EXISTS Attendees;
DROP TABLE IF EXISTS Talk_Activities;
DROP TABLE IF EXISTS Toolbox_Talks;
DROP TABLE IF EXISTS Control_Measures;
DROP TABLE IF EXISTS Risk_Assessments;
DROP TABLE IF EXISTS Hazards;
DROP TABLE IF EXISTS Activities;
DROP TABLE IF EXISTS Users;
DROP TABLE IF EXISTS Departments;
DROP TABLE IF EXISTS Organizations;

-- User Management Tables
CREATE TABLE Organizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT,
    contact_info TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    organization_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES Organizations(id)
);

CREATE TABLE Users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'safety_officer', 'employee')),
    organization_id INTEGER NOT NULL,
    department_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES Organizations(id),
    FOREIGN KEY (department_id) REFERENCES Departments(id)
);

-- HIRARC Core Tables
CREATE TABLE Activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    department_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'inactive', 'archived')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES Departments(id),
    FOREIGN KEY (created_by) REFERENCES Users(id)
);

CREATE TABLE Hazards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    activity_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    hazard_type TEXT NOT NULL CHECK (hazard_type IN ('health', 'safety', 'environmental')),
    suggested_by_ai BOOLEAN DEFAULT FALSE,
    created_by INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (activity_id) REFERENCES Activities(id),
    FOREIGN KEY (created_by) REFERENCES Users(id)
);

CREATE TABLE Risk_Assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hazard_id INTEGER NOT NULL,
    likelihood INTEGER NOT NULL CHECK (likelihood BETWEEN 1 AND 5),
    severity INTEGER NOT NULL CHECK (severity BETWEEN 1 AND 5),
    risk_level INTEGER GENERATED ALWAYS AS (likelihood * severity) STORED,
    created_by INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hazard_id) REFERENCES Hazards(id),
    FOREIGN KEY (created_by) REFERENCES Users(id)
);

CREATE TABLE Control_Measures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hazard_id INTEGER NOT NULL,
    assessment_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    control_type TEXT NOT NULL CHECK (control_type IN ('elimination', 'substitution', 'engineering', 'administrative', 'ppe')),
    status TEXT NOT NULL CHECK (status IN ('planned', 'implemented', 'verified', 'ineffective')),
    suggested_by_ai BOOLEAN DEFAULT FALSE,
    created_by INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hazard_id) REFERENCES Hazards(id),
    FOREIGN KEY (assessment_id) REFERENCES Risk_Assessments(id),
    FOREIGN KEY (created_by) REFERENCES Users(id)
);

-- Toolbox Talk Tables
CREATE TABLE Toolbox_Talks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    date_time TIMESTAMP NOT NULL,
    location TEXT,
    department_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES Departments(id),
    FOREIGN KEY (created_by) REFERENCES Users(id)
);

CREATE TABLE Talk_Activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    toolbox_talk_id INTEGER NOT NULL,
    activity_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (toolbox_talk_id) REFERENCES Toolbox_Talks(id),
    FOREIGN KEY (activity_id) REFERENCES Activities(id)
);

CREATE TABLE Attendees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    toolbox_talk_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    attendance BOOLEAN DEFAULT FALSE,
    feedback TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (toolbox_talk_id) REFERENCES Toolbox_Talks(id),
    FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- Workplace Audit Tables
CREATE TABLE Audit_Plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    department_id INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('planned', 'in_progress', 'completed', 'cancelled')),
    created_by INTEGER NOT NULL,
    scheduled_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES Departments(id),
    FOREIGN KEY (created_by) REFERENCES Users(id)
);

CREATE TABLE Audit_Findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    audit_plan_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('critical', 'major', 'minor', 'observation')),
    status TEXT NOT NULL CHECK (status IN ('open', 'in_progress', 'closed')),
    photo_url TEXT,
    created_by INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (audit_plan_id) REFERENCES Audit_Plans(id),
    FOREIGN KEY (created_by) REFERENCES Users(id)
);

CREATE TABLE Corrective_Actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    assigned_to INTEGER NOT NULL,
    due_date DATE NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('assigned', 'in_progress', 'completed', 'verified')),
    created_by INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (finding_id) REFERENCES Audit_Findings(id),
    FOREIGN KEY (assigned_to) REFERENCES Users(id),
    FOREIGN KEY (created_by) REFERENCES Users(id)
);

-- Permit to Work Tables
CREATE TABLE Permit_Requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    work_type TEXT NOT NULL CHECK (work_type IN ('cold_work', 'hot_work', 'confined_space', 'electrical', 'excavation', 'height_work')),
    location TEXT NOT NULL,
    start_date TIMESTAMP NOT NULL,
    end_date TIMESTAMP NOT NULL,
    requester_id INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft', 'submitted', 'approved', 'rejected', 'cancelled', 'completed')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (requester_id) REFERENCES Users(id)
);

CREATE TABLE Permit_Approvals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    permit_id INTEGER NOT NULL,
    approver_id INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected')),
    comments TEXT,
    approval_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (permit_id) REFERENCES Permit_Requests(id),
    FOREIGN KEY (approver_id) REFERENCES Users(id)
);

CREATE TABLE Permit_Hazards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    permit_id INTEGER NOT NULL,
    hazard_id INTEGER NOT NULL,
    control_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (permit_id) REFERENCES Permit_Requests(id),
    FOREIGN KEY (hazard_id) REFERENCES Hazards(id),
    FOREIGN KEY (control_id) REFERENCES Control_Measures(id)
);

-- Create Indexes
-- User Management Indexes
CREATE INDEX idx_users_email ON Users(email);
CREATE INDEX idx_users_organization ON Users(organization_id);
CREATE INDEX idx_users_department ON Users(department_id);
CREATE INDEX idx_departments_organization ON Departments(organization_id);

-- HIRARC Core Indexes
CREATE INDEX idx_activities_department ON Activities(department_id);
CREATE INDEX idx_activities_status ON Activities(status);
CREATE INDEX idx_hazards_activity ON Hazards(activity_id);
CREATE INDEX idx_hazards_type ON Hazards(hazard_type);
CREATE INDEX idx_risk_assessments_hazard ON Risk_Assessments(hazard_id);
CREATE INDEX idx_risk_assessments_level ON Risk_Assessments(risk_level);
CREATE INDEX idx_control_measures_hazard ON Control_Measures(hazard_id);
CREATE INDEX idx_control_measures_assessment ON Control_Measures(assessment_id);
CREATE INDEX idx_control_measures_status ON Control_Measures(status);

-- Toolbox Talk Indexes
CREATE INDEX idx_toolbox_talks_department ON Toolbox_Talks(department_id);
CREATE INDEX idx_toolbox_talks_date ON Toolbox_Talks(date_time);
CREATE INDEX idx_talk_activities_talk ON Talk_Activities(toolbox_talk_id);
CREATE INDEX idx_talk_activities_activity ON Talk_Activities(activity_id);
CREATE INDEX idx_attendees_talk ON Attendees(toolbox_talk_id);
CREATE INDEX idx_attendees_user ON Attendees(user_id);

-- Workplace Audit Indexes
CREATE INDEX idx_audit_plans_department ON Audit_Plans(department_id);
CREATE INDEX idx_audit_plans_status ON Audit_Plans(status);
CREATE INDEX idx_audit_plans_date ON Audit_Plans(scheduled_date);
CREATE INDEX idx_audit_findings_plan ON Audit_Findings(audit_plan_id);
CREATE INDEX idx_audit_findings_status ON Audit_Findings(status);
CREATE INDEX idx_corrective_actions_finding ON Corrective_Actions(finding_id);
CREATE INDEX idx_corrective_actions_assigned ON Corrective_Actions(assigned_to);
CREATE INDEX idx_corrective_actions_status ON Corrective_Actions(status);

-- Permit to Work Indexes
CREATE INDEX idx_permit_requests_requester ON Permit_Requests(requester_id);
CREATE INDEX idx_permit_requests_status ON Permit_Requests(status);
CREATE INDEX idx_permit_requests_dates ON Permit_Requests(start_date, end_date);
CREATE INDEX idx_permit_approvals_permit ON Permit_Approvals(permit_id);
CREATE INDEX idx_permit_approvals_approver ON Permit_Approvals(approver_id);
CREATE INDEX idx_permit_approvals_status ON Permit_Approvals(status);
CREATE INDEX idx_permit_hazards_permit ON Permit_Hazards(permit_id);
CREATE INDEX idx_permit_hazards_hazard ON Permit_Hazards(hazard_id);

-- Create Views
-- High Risk Activities View
CREATE VIEW High_Risk_Activities AS
SELECT 
    a.id AS activity_id,
    a.name AS activity_name,
    a.department_id,
    d.name AS department_name,
    COUNT(h.id) AS hazard_count,
    MAX(ra.risk_level) AS max_risk_level
FROM 
    Activities a
JOIN 
    Departments d ON a.department_id = d.id
LEFT JOIN 
    Hazards h ON a.id = h.activity_id
LEFT JOIN 
    Risk_Assessments ra ON h.id = ra.hazard_id
WHERE 
    a.status = 'active'
GROUP BY 
    a.id
HAVING 
    MAX(ra.risk_level) >= 15
ORDER BY 
    max_risk_level DESC;

-- Control Measures Implementation Status View
CREATE VIEW Control_Implementation_Status AS
SELECT 
    cm.id AS control_id,
    h.activity_id,
    a.name AS activity_name,
    h.id AS hazard_id,
    h.description AS hazard_description,
    ra.risk_level,
    cm.description AS control_description,
    cm.control_type,
    cm.status,
    u.name AS created_by_name,
    cm.created_at,
    cm.updated_at
FROM 
    Control_Measures cm
JOIN 
    Hazards h ON cm.hazard_id = h.id
JOIN 
    Activities a ON h.activity_id = a.id
JOIN 
    Risk_Assessments ra ON cm.assessment_id = ra.id
JOIN 
    Users u ON cm.created_by = u.id
ORDER BY 
    ra.risk_level DESC, cm.status;

-- Upcoming Toolbox Talks View
CREATE VIEW Upcoming_Toolbox_Talks AS
SELECT 
    tt.id,
    tt.title,
    tt.description,
    tt.date_time,
    tt.location,
    d.name AS department_name,
    u.name AS created_by_name,
    COUNT(ta.id) AS activities_count,
    COUNT(att.id) AS attendees_count
FROM 
    Toolbox_Talks tt
JOIN 
    Departments d ON tt.department_id = d.id
JOIN 
    Users u ON tt.created_by = u.id
LEFT JOIN 
    Talk_Activities ta ON tt.id = ta.toolbox_talk_id
LEFT JOIN 
    Attendees att ON tt.id = att.toolbox_talk_id
WHERE 
    tt.date_time > CURRENT_TIMESTAMP
GROUP BY 
    tt.id
ORDER BY 
    tt.date_time;

-- Open Audit Findings View
CREATE VIEW Open_Audit_Findings AS
SELECT 
    af.id,
    ap.title AS audit_title,
    af.description,
    af.severity,
    af.status,
    d.name AS department_name,
    u.name AS created_by_name,
    af.created_at,
    COUNT(ca.id) AS corrective_actions_count,
    SUM(CASE WHEN ca.status = 'completed' THEN 1 ELSE 0 END) AS completed_actions_count
FROM 
    Audit_Findings af
JOIN 
    Audit_Plans ap ON af.audit_plan_id = ap.id
JOIN 
    Departments d ON ap.department_id = d.id
JOIN 
    Users u ON af.created_by = u.id
LEFT JOIN 
    Corrective_Actions ca ON af.id = ca.finding_id
WHERE 
    af.status != 'closed'
GROUP BY 
    af.id
ORDER BY 
    CASE af.severity
        WHEN 'critical' THEN 1
        WHEN 'major' THEN 2
        WHEN 'minor' THEN 3
        WHEN 'observation' THEN 4
    END,
    af.created_at;

-- Active Permits View
CREATE VIEW Active_Permits AS
SELECT 
    pr.id,
    pr.title,
    pr.description,
    pr.work_type,
    pr.location,
    pr.start_date,
    pr.end_date,
    pr.status,
    u.name AS requester_name,
    COUNT(ph.id) AS hazards_count,
    COUNT(DISTINCT pa.approver_id) AS approvers_count,
    SUM(CASE WHEN pa.status = 'approved' THEN 1 ELSE 0 END) AS approved_count
FROM 
    Permit_Requests pr
JOIN 
    Users u ON pr.requester_id = u.id
LEFT JOIN 
    Permit_Hazards ph ON pr.id = ph.permit_id
LEFT JOIN 
    Permit_Approvals pa ON pr.id = pa.permit_id
WHERE 
    pr.status IN ('submitted', 'approved') AND
    pr.end_date > CURRENT_TIMESTAMP
GROUP BY 
    pr.id
ORDER BY 
    pr.start_date;

-- Insert seed data for testing
-- Default organization
INSERT INTO Organizations (name, address, contact_info) 
VALUES ('Safety First Sdn Bhd', 'Jalan Teknologi, Kuala Lumpur', 'contact@safetyfirst.com.my');

-- Default departments
INSERT INTO Departments (name, organization_id) 
VALUES 
('Administration', 1),
('Operations', 1),
('Maintenance', 1),
('Safety', 1);

-- Default admin user (password: admin123)
INSERT INTO Users (name, email, password_hash, role, organization_id, department_id) 
VALUES ('Admin User', 'admin@safetyfirst.com.my', '$2a$10$JwXdETcLJkKN7GY1.cRz7OgwOmxPdVMuegZHsy2vmTWIuWUhK0Ady', 'admin', 1, 1);

-- Default safety officer (password: safety123)
INSERT INTO Users (name, email, password_hash, role, organization_id, department_id) 
VALUES ('Safety Officer', 'safety@safetyfirst.com.my', '$2a$10$JwXdETcLJkKN7GY1.cRz7OgwOmxPdVMuegZHsy2vmTWIuWUhK0Ady', 'safety_officer', 1, 4);

-- Default employee (password: employee123)
INSERT INTO Users (name, email, password_hash, role, organization_id, department_id) 
VALUES ('Employee User', 'employee@safetyfirst.com.my', '$2a$10$JwXdETcLJkKN7GY1.cRz7OgwOmxPdVMuegZHsy2vmTWIuWUhK0Ady', 'employee', 1, 2);
