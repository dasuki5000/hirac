# HIRARC Research Summary

This document summarizes the key findings from our research on the Department of Occupational Safety and Health (DOSH) Malaysia's 2008 Guidelines for Hazard Identification, Risk Assessment, and Risk Control (HIRARC).

## Key Components Researched

1. **HIRARC Definitions and Purpose**
   - Hazard: A source or situation with potential for harm
   - Risk: Combination of likelihood and severity of a hazardous event
   - Risk Assessment: Process of evaluating risks to safety and health
   - Risk Management: Total procedure for identifying hazards, assessing risks, implementing controls, and reviewing outcomes

2. **HIRARC Process Steps**
   - Classify work activities
   - Identify hazards
   - Conduct risk assessment (analyze and estimate risk)
   - Apply risk control measures

3. **Hazard Types**
   - Health hazards (chemicals, biological, physical agents, ergonomic)
   - Safety hazards (mechanical, electrical, fall hazards, etc.)
   - Environmental hazards

4. **Risk Assessment Methodology**
   - Qualitative, semi-quantitative, and quantitative methods
   - Likelihood ratings (1-5 scale)
   - Severity ratings (1-5 scale)
   - Risk calculation: Risk = Likelihood × Severity

5. **Risk Matrix and Prioritization**
   - 5×5 risk matrix combining likelihood and severity
   - Risk levels: High (15-25), Medium (5-12), Low (1-4)
   - Action requirements for each risk level

6. **Control Measures**
   - Hierarchy of controls (source > path > worker)
   - Elimination and substitution at the source
   - Engineering controls
   - Administrative controls
   - Personal protective equipment (least desirable)

## Implications for Web Application Design

Based on our research, the HIRARC web application should include:

1. **User Authentication and Role Management**
   - Different permission levels for administrators, safety officers, and general employees

2. **Work Activity Classification Module**
   - Ability to categorize and organize workplace activities

3. **Hazard Identification System**
   - AI-powered hazard suggestion based on activity type
   - Categorization by health, safety, and environmental hazards

4. **Risk Assessment Module**
   - Implementation of the 5×5 risk matrix
   - Automatic calculation of risk levels
   - Visual representation of risk distribution

5. **Control Measure Recommendations**
   - AI-suggested control measures based on hazard type and risk level
   - Hierarchy of controls implementation
   - Documentation of control implementation status

6. **Integration Features**
   - Toolbox talks generation based on HIRARC data
   - Workplace inspection findings integration
   - Permit to work system connection

7. **Reporting and Monitoring**
   - Real-time monitoring of high-risk activities
   - Comprehensive reporting features
   - Review scheduling and tracking

This research provides a solid foundation for designing a web application that will help safety practitioners in Malaysia create and manage HIRARC assessments in compliance with DOSH Guidelines 2008.
