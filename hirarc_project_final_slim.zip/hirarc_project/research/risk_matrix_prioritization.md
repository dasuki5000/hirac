# Risk Matrix and Prioritization Levels from DOSH Guidelines 2008

## Risk Matrix (Table C)

The DOSH Guidelines 2008 provides a risk matrix (Table C) that combines likelihood and severity ratings to determine the risk level. This matrix is a 5x5 grid with:

- Likelihood (L) values from 1-5 on the vertical axis
- Severity (S) values from 1-5 on the horizontal axis
- Risk values (L × S) ranging from 1 to 25 in the cells

### Risk Matrix Table

| Likelihood (L) | Severity (S) |  |  |  |  |
|----------------|-------------|-------------|-------------|-------------|-------------|
|                | 1 | 2 | 3 | 4 | 5 |
| 5 | 5 | 10 | 15 | 20 | 25 |
| 4 | 4 | 8 | 12 | 16 | 20 |
| 3 | 3 | 6 | 9 | 12 | 15 |
| 2 | 2 | 4 | 6 | 8 | 10 |
| 1 | 1 | 2 | 3 | 4 | 5 |

### Risk Levels

The risk matrix uses color coding to indicate risk levels:
- **High Risk**: Red cells
- **Medium Risk**: Yellow cells
- **Low Risk**: Green cells

## Risk Prioritization (Table D)

The relative risk value can be used to prioritize necessary actions to effectively manage workplace hazards. Table D determines priority based on the following ranges:

| RISK | DESCRIPTION | ACTION |
|------|-------------|--------|
| 15 - 25 | HIGH | A HIGH risk requires **immediate** action to control the hazard as detailed in the hierarchy of control. Actions taken must be documented on the risk assessment form including date for completion. |
| 5 - 12 | MEDIUM | A MEDIUM risk requires a planned approach to controlling the hazard and applies temporary measure if required. Actions taken must be documented on the risk assessment form including date for completion. |
| 1 - 4 | LOW | A risk identified as LOW may be considered as acceptable and further reduction may not be necessary. However, if the risk can be resolved quickly and efficiently, control measures should be implemented and recorded. |

## Using the Risk Matrix

To use this matrix:
1. Find the severity column that best describes the outcome of risk
2. Follow the likelihood row to find the description that best suits the likelihood that the severity will occur
3. The risk level is given in the box where the row and column meet

## Implications for Web Application Design

For our HIRARC web application, we should:

1. Implement the 5x5 risk matrix with color coding for risk levels
2. Automatically calculate risk values based on selected likelihood and severity ratings
3. Categorize risks into HIGH, MEDIUM, and LOW based on the specified ranges
4. Provide appropriate action recommendations based on risk level
5. Include documentation features for recording control actions and completion dates
6. Implement prioritization of hazards based on risk level
7. Design visual indicators (color coding) for easy identification of risk levels
8. Enable filtering and sorting of hazards by risk level
9. Implement AI suggestions for control measures based on risk level
10. Include reporting features that highlight high-risk areas requiring immediate attention
