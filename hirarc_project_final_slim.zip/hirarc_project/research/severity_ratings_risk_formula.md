# Severity Ratings and Risk Assessment Formula from DOSH Guidelines 2008

## Severity of Hazard

According to the DOSH Guidelines 2008, severity can be divided into five categories. Severity is based upon an increasing level of severity to an individual's health, the environment, or to property.

### Severity Rating Table (Table B)

| SEVERITY (S) | EXAMPLE | RATING |
|--------------|---------|--------|
| Catastrophic | Numerous fatalities, irrecoverable property damage and productivity | 5 |
| Fatal | Approximately one single fatality, major property damage if hazard is realized | 4 |
| Serious | Non-fatal injury, permanent disability | 3 |
| Minor | Disabling but not permanent injury | 2 |
| Negligible | Minor abrasions, bruises, cuts, first aid type injury | 1 |

This standardized severity rating table provides a consistent framework for assessing the potential impact of hazards in the workplace.

## Risk Assessment Formula

Risk can be presented in a variety of ways to communicate the results of analysis to make decisions on risk control. For risk analysis that uses likelihood and severity in qualitative method, presenting results in a risk matrix is a very effective way of communicating the distribution of risk throughout a plant and area in a workplace.

The risk calculation formula is:

**L × S = Relative Risk**

Where:
- L = Likelihood (from Table A, ratings 1-5)
- S = Severity (from Table B, ratings 1-5)

This formula produces a risk rating between 1 and 25, which can be used to prioritize hazards and determine appropriate control measures.

## Risk Matrix Implications

The resulting risk values (1-25) can be categorized into risk levels:
- High Risk: Requiring immediate action
- Medium Risk: Requiring planned action
- Low Risk: Requiring routine procedures

(Note: The specific risk level thresholds will be found on subsequent pages of the guidelines)

## Implications for Web Application Design

For our HIRARC web application, we should:

1. Implement the severity rating table with descriptions and ratings
2. Allow for customization of severity descriptions while maintaining the 1-5 rating scale
3. Provide guidance on selecting the appropriate severity rating with examples
4. Implement the risk calculation formula (L × S = Risk)
5. Create a visual risk matrix to display results
6. Color-code risk levels for easy identification (typically red for high, yellow for medium, green for low)
7. Enable sorting and filtering of hazards by risk level
8. Implement AI suggestions for severity ratings based on hazard type
9. Provide recommendations for control measures based on risk level
10. Include reporting features that highlight high-risk areas
