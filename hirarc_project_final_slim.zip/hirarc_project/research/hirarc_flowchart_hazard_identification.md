# HIRARC Flowchart and Hazard Identification

## HIRARC Process Flowchart
The DOSH Guidelines 2008 provides a flowchart for the HIRARC process that includes the following steps:

1. Classify work activities
2. Consultation (involving both Employer Representatives and Worker Representatives)
3. Identify Hazards
4. Risk Assessment
5. Prepare Risk Control Action Plan (If Necessary)
6. Implement
7. Review (continuous loop back to Identify Hazards)

This flowchart emphasizes the importance of consultation between employer and worker representatives, as well as the continuous review process that feeds back into hazard identification.

## Work Activity Classification
Work activities should be classified according to their similarity, such as:

1. Geographical or physical areas within/outside premises
2. Stages in production/service process
3. Not too big (e.g., building a car)
4. Not too small (e.g., fixing a nut)
5. Defined tasks (e.g., loading, packing, mixing, fixing the door)

This classification helps in organizing the HIRARC process and ensures that all workplace activities are systematically assessed.

## Hazard Identification
The purpose of hazard identification is to highlight the critical operations of tasks that pose significant risks to the health and safety of employees, as well as highlighting hazards pertaining to certain equipment due to energy sources, working conditions, or activities performed.

Hazards can be divided into three main groups:

### 1. Health Hazards
An occupational health hazard is any agent that can cause illness to an individual. Health hazards may produce:
- Serious and immediate (acute) effects
- Long-term (chronic) problems
- Effects on any part of the body

Examples include noise-induced hearing loss, which is often difficult for the affected individual to detect until it is well advanced.

### 2. Safety Hazards
(Details to be found on subsequent pages)

### 3. Environmental Hazards
(Details to be found on subsequent pages)

This categorization of hazards is essential for the web application's hazard identification module, which will need to guide users through identifying different types of hazards for their workplace activities.
