# HIRARC Process Steps from DOSH Guidelines 2008

## Purpose of HIRARC
The purpose of HIRARC as defined in the DOSH Guidelines are:

1. To identify all the factors that may cause harm to employees and others (the hazards)
2. To consider what the chances are of that harm actually befalling anyone in the circumstances of a particular case and the possible severity that could come from it (the risks)
3. To enable employers to plan, introduce and monitor preventive measures to ensure that the risks are adequately controlled at all times

## When to Conduct HIRARC
HIRARC activities shall be planned and conducted for situations where:
1. Hazards appear to pose significant threat
2. Uncertain whether existing controls are adequate
3. Before implementing corrective or preventive measures
4. By organizations intending to continuously improve OSH Management System

## HIRARC Process
The HIRARC process requires 4 simple steps:

### 1. Classify Work Activities
- Categorize workplace activities systematically
- Break down processes into manageable components
- Can be organized by department, process, or location

### 2. Identify Hazards
- Identify all potential sources of harm
- Consider health, safety, and environmental hazards
- Document all identified hazards

### 3. Conduct Risk Assessment
- Analyze and estimate risk from each hazard by calculating or estimating:
  - Likelihood of occurrence
  - Severity of hazard

### 4. Risk Control
- Decide if risk is tolerable
- Apply control measures if necessary
- Follow hierarchy of controls

## Risk Calculation
Risk is calculated using the formula:
**Risk = Likelihood × Severity**

### Likelihood
An event likely to occur within the specific period or in specified circumstances.

### Severity
Outcome from an event such as severity of injury or health of people, or damage to property, or insult to environment, or any combination of those caused by the event.

## Implementation Requirements
- Employer should assign trained personnel to lead a HIRARC team
- Team should include employees associated with the particular process or activity
- Documentation of the entire process is essential
- Regular review and updates are required
