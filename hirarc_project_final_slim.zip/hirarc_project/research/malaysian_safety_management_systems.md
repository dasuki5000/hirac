# Malaysian Safety Management Systems Research

## MS 1722:2011 - Occupational Safety and Health Management Systems

MS 1722:2011 is the Malaysian Standard that provides requirements for Occupational Safety and Health Management Systems (OSHMS) in Malaysia. This standard enables organizations to manage their OHS risks and improve OHS performance.

### Key Components of MS 1722:2011

The standard is based on the **POPEA** framework, which consists of five main elements:

1. **Policy** 
   - Development of the organization's OSH policy statement
   - Structures and practices that ensure active worker participation in OSH arrangements

2. **Organizing**
   - Establishment of OSH responsibilities and accountabilities
   - Training systems and competency definitions
   - Documentation practices
   - Communication systems

3. **Planning and Implementation**
   - Activities associated with fulfilling the principles in the OSH policy
   - Initial assessment of OSH arrangements
   - System planning, development, and implementation

4. **Evaluation**
   - Performance monitoring and measurement
   - Incident investigation
   - Auditing methods
   - Management review arrangements

5. **Action for Improvement**
   - Preventive/corrective actions
   - Continual improvement processes
   - Implementation of actions based on performance monitoring

### Relationship to HIRARC

HIRARC (Hazard Identification, Risk Assessment, and Risk Control) is a fundamental component that fits within the broader OSHMS framework, particularly in the Planning and Implementation phase. The HIRARC process provides the systematic methodology for identifying workplace hazards, assessing their risks, and implementing appropriate controls.

### Integration Points for Web Application

Based on this research, our web application should:

1. **Align with POPEA Framework**
   - Ensure the HIRARC module is positioned as part of the broader OSHMS
   - Include policy documentation capabilities
   - Support organizational structure and responsibility assignment

2. **Support Evaluation Requirements**
   - Enable performance monitoring of implemented controls
   - Facilitate incident investigation documentation
   - Support audit processes
   - Provide management review capabilities

3. **Enable Action for Improvement**
   - Track preventive and corrective actions
   - Monitor implementation status
   - Support continual improvement processes

4. **Documentation Requirements**
   - Ensure all HIRARC processes are properly documented
   - Support record-keeping requirements
   - Enable reporting aligned with Malaysian regulatory requirements

This integration will ensure that our HIRARC web application not only meets the specific requirements of the DOSH Guidelines 2008 but also aligns with the broader OSHMS framework as defined in MS 1722:2011.
