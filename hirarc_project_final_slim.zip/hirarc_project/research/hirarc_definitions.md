# HIRARC Key Definitions from DOSH Guidelines 2008

## Purpose
The purpose of the DOSH guideline is to provide a systematic and objective approach to assessing hazards and their associated risks that will provide an objective measure of an identified hazard as well as provide a method to control the risk. It is one of the general duties as prescribed under the Occupational Safety and Health Act 1994 (Act 514) for the employer to provide safe workplaces to their employees and other related persons.

## Key Definitions

### Hazard
A source or a situation with a potential for harm in terms of human injury or ill health, damage to property, damage to the environment or a combination of these.

### Hazard Control
The process of implementing measures to reduce the risk associated with a hazard.

### Hierarchy of Control
The established priority order for the types of measures to be used to control risks.

### Hazard Identification
The identification of undesired events that lead to the materialization of the hazard and the mechanism by which those undesired events could occur.

### Risk
A combination of the likelihood of an occurrence of a hazardous event with specified period or in specified circumstances and the severity of injury or damage to the health of people, property, environment or any combination of these caused by the event.

### Risk Assessment
The process of evaluating the risks to safety and health arising from hazards at work.

### Risk Management
The total procedure associated with identifying a hazard, assessing the risk, putting in place control measures, and reviewing the outcomes.

## Risk Calculation

Risk is the combination of the likelihood and severity of a specified hazardous event occurring. In mathematical terms, risk can be calculated by the equation:

**Risk = Likelihood × Severity**

This fundamental equation forms the basis of the risk assessment methodology in HIRARC.
